"use strict";
(() => {
  // code.ts
  var thumbnailCache = /* @__PURE__ */ new Map();
  var isCreatingGrid = false;
  async function loadUserPreferences() {
    try {
      const prefs = await figma.clientStorage.getAsync("userPreferences");
      return prefs;
    } catch (error) {
      console.error("Error loading user preferences:", error);
      return null;
    }
  }
  async function saveUserPreferences(prefs) {
    try {
      await figma.clientStorage.setAsync("userPreferences", prefs);
      console.log("User preferences saved");
    } catch (error) {
      console.error("Error saving user preferences:", error);
    }
  }
  async function saveGridConfigAsPreferences(config) {
    const prefs = {
      lastConfig: {
        frameName: config.frameName,
        headerTitle: config.headerTitle || "",
        columns: config.columns,
        gap: config.gap,
        showLabels: config.showLabels,
        enableLabelLinks: config.enableLabelLinks || false
      },
      lastUsed: Date.now()
    };
    await saveUserPreferences(prefs);
  }
  function loadBadgeCache() {
    try {
      const cacheJson = figma.root.getPluginData("badgeCache");
      if (!cacheJson) {
        return { version: 1, badges: {} };
      }
      return JSON.parse(cacheJson);
    } catch (error) {
      console.error("Error loading badge cache:", error);
      return { version: 1, badges: {} };
    }
  }
  function saveBadgeCache(cache) {
    try {
      figma.root.setPluginData("badgeCache", JSON.stringify(cache));
      console.log("Badge cache saved:", Object.keys(cache.badges).length, "entries");
    } catch (error) {
      console.error("Error saving badge cache:", error);
    }
  }
  function updateBadgeInCache(nodeId, nodeName, badge) {
    const cache = loadBadgeCache();
    cache.badges[nodeId] = {
      name: nodeName,
      badge,
      lastModified: Date.now()
    };
    saveBadgeCache(cache);
  }
  function removeBadgeFromCache(nodeId) {
    const cache = loadBadgeCache();
    if (cache.badges[nodeId]) {
      delete cache.badges[nodeId];
      saveBadgeCache(cache);
    }
  }
  function getBadgeFromCache(nodeId) {
    const cache = loadBadgeCache();
    const entry = cache.badges[nodeId];
    return entry ? entry.badge : null;
  }
  async function syncBadgesFromCache() {
    const cache = loadBadgeCache();
    let restoredCount = 0;
    let cleanedCount = 0;
    let cacheModified = false;
    const badgeIds = Object.keys(cache.badges);
    for (const nodeId of badgeIds) {
      try {
        const node = await figma.getNodeByIdAsync(nodeId);
        if (node && (node.type === "COMPONENT" || node.type === "INSTANCE")) {
          const existingBadge = node.getPluginData("badge");
          if (!existingBadge) {
            const entry = cache.badges[nodeId];
            node.setPluginData("badge", JSON.stringify(entry.badge));
            restoredCount++;
            console.log(`Restored badge for: ${entry.name}`);
          }
        } else {
          delete cache.badges[nodeId];
          cacheModified = true;
          cleanedCount++;
          console.log(`Removed stale badge entry for deleted node: ${nodeId}`);
        }
      } catch (error) {
        console.error(`Error syncing badge for node ${nodeId}:`, error);
      }
    }
    if (cacheModified) {
      saveBadgeCache(cache);
      console.log(`Cleaned ${cleanedCount} stale entries from badge cache`);
    }
    return restoredCount;
  }
  function setBadge(node, badge) {
    node.setPluginData("badge", JSON.stringify(badge));
    updateBadgeInCache(node.id, node.name, badge);
  }
  function getBadge(node) {
    try {
      const badgeJson = node.getPluginData("badge");
      if (badgeJson) {
        return JSON.parse(badgeJson);
      }
      const cachedBadge = getBadgeFromCache(node.id);
      if (cachedBadge) {
        node.setPluginData("badge", JSON.stringify(cachedBadge));
        console.log(`Badge restored from cache for: ${node.name}`);
        return cachedBadge;
      }
      return null;
    } catch (error) {
      console.error("Error parsing badge data:", error);
      return null;
    }
  }
  function removeBadge(node) {
    node.setPluginData("badge", "");
    removeBadgeFromCache(node.id);
  }
  function getBadgeColor(badgeType) {
    const colors = {
      "new": { r: 0.078, g: 0.682, b: 0.361 },
      // #14AE5C
      "updated": { r: 0.051, g: 0.6, b: 1 },
      // #0D99FF
      "deprecated": { r: 0.949, g: 0.282, b: 0.133 },
      // #F24822
      "beta": { r: 0.592, g: 0.278, b: 1 },
      // #9747FF
      "legacy": { r: 0.4, g: 0.4, b: 0.4 }
      // #666666
    };
    return colors[badgeType] || colors["new"];
  }
  async function createBadgeElement(badge) {
    await figma.loadFontAsync({ family: "Inter", style: "Bold" });
    const badgeFrame = figma.createFrame();
    badgeFrame.name = "Badge";
    badgeFrame.resize(40, 16);
    badgeFrame.fills = [{
      type: "SOLID",
      color: badge.color ? hexToRgb(badge.color) : getBadgeColor(badge.type)
    }];
    badgeFrame.cornerRadius = 4;
    badgeFrame.layoutMode = "HORIZONTAL";
    badgeFrame.paddingLeft = 6;
    badgeFrame.paddingRight = 6;
    badgeFrame.primaryAxisAlignItems = "CENTER";
    badgeFrame.counterAxisAlignItems = "CENTER";
    const badgeText = figma.createText();
    badgeText.characters = badge.type.toUpperCase();
    badgeText.fontSize = 9;
    badgeText.fontName = { family: "Inter", style: "Bold" };
    badgeText.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 } }];
    badgeText.textAutoResize = "WIDTH_AND_HEIGHT";
    badgeFrame.appendChild(badgeText);
    return badgeFrame;
  }
  function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16) / 255,
      g: parseInt(result[2], 16) / 255,
      b: parseInt(result[3], 16) / 255
    } : { r: 0, g: 0, b: 0 };
  }
  figma.showUI(__html__, {
    width: 900,
    height: 700,
    themeColors: true
  });
  (async () => {
    const restoredCount = await syncBadgesFromCache();
    if (restoredCount > 0) {
      figma.notify(`\u2705 Restored ${restoredCount} badge(s) from cache`);
    }
    const cache = loadBadgeCache();
    console.log(`Badge cache loaded: ${Object.keys(cache.badges).length} entries`);
    const userPrefs = await loadUserPreferences();
    if (userPrefs) {
      figma.ui.postMessage({
        type: "load-preferences",
        preferences: userPrefs.lastConfig
      });
      console.log("User preferences loaded:", userPrefs.lastConfig.frameName);
    }
  })();
  function findExistingFrame(frameName) {
    const existingFrames = figma.currentPage.findAll(
      (node) => node.type === "FRAME" && node.name === frameName
    );
    if (existingFrames.length > 1) {
      figma.notify(`Warning: ${existingFrames.length} frames named "${frameName}" found. Reusing the first one.`);
    }
    if (existingFrames.length > 0) {
      const frame = existingFrames[0];
      const children = [...frame.children];
      children.forEach((child) => child.remove());
      console.log(`Reusing existing frame: "${frameName}"`);
      return frame;
    }
    const newFrame = figma.createFrame();
    newFrame.name = frameName;
    console.log(`Creating new frame: "${frameName}"`);
    return newFrame;
  }
  async function calculateSelectionBounds(iconIds) {
    if (iconIds.length === 0)
      return null;
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const iconId of iconIds) {
      const node = await figma.getNodeByIdAsync(iconId);
      if (node && "absoluteBoundingBox" in node && node.absoluteBoundingBox) {
        const bounds = node.absoluteBoundingBox;
        minX = Math.min(minX, bounds.x);
        minY = Math.min(minY, bounds.y);
        maxX = Math.max(maxX, bounds.x + bounds.width);
        maxY = Math.max(maxY, bounds.y + bounds.height);
      }
    }
    if (minX === Infinity)
      return null;
    return { minX, minY, maxX, maxY };
  }
  function getSelectedComponents() {
    const selection = figma.currentPage.selection;
    console.log("=== SELECTION DEBUG ===");
    console.log("Total selection count:", selection.length);
    console.log("Selection types:", selection.map((n) => `${n.name} (${n.type})`).join(", "));
    const filtered = selection.filter(
      (node) => node.type === "COMPONENT" || node.type === "INSTANCE"
    );
    console.log("Filtered components/instances:", filtered.length);
    console.log("======================");
    return filtered;
  }
  async function getIconData(component) {
    try {
      let thumbnail = thumbnailCache.get(component.id);
      if (!thumbnail) {
        thumbnail = await component.exportAsync({
          format: "PNG",
          constraint: { type: "SCALE", value: 2 }
        });
        thumbnailCache.set(component.id, thumbnail);
      }
      const badge = getBadge(component);
      return {
        id: component.id,
        name: component.name,
        thumbnail,
        badge: badge || void 0
      };
    } catch (error) {
      console.error("Error generating thumbnail for", component.name, error);
      throw error;
    }
  }
  function getIconCategory(name) {
    const lowerName = name.toLowerCase();
    if (lowerName.startsWith("basic/") || lowerName.includes("/basic/")) {
      return "Basic" /* Basic */;
    }
    if (lowerName.startsWith("illustrated/") || lowerName.startsWith("colored/") || lowerName.includes("/illustrated/") || lowerName.includes("/colored/")) {
      return "Illustrated" /* Illustrated */;
    }
    return "Basic" /* Basic */;
  }
  function toComponentName(name) {
    return name.split("/").map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()).join("").replace(/[^a-zA-Z0-9]/g, "");
  }
  function toSnakeCaseName(name) {
    return name.toLowerCase().replace(/\//g, "_").replace(/[^a-z0-9_]/g, "");
  }
  async function exportComponentAsSVG(component) {
    try {
      const svgData = await component.exportAsync({
        format: "SVG",
        svgIdAttribute: false,
        svgOutlineText: true
      });
      const svgString = String.fromCharCode.apply(null, Array.from(svgData));
      return svgString;
    } catch (error) {
      console.error("Error exporting SVG for", component.name, error);
      throw error;
    }
  }
  function processSVGContent(svg) {
    let cleanSVG = svg.replace(/<\?xml[^>]*\?>/g, "");
    const viewBoxMatch = cleanSVG.match(/viewBox="([^"]*)"/);
    const viewBox = viewBoxMatch ? viewBoxMatch[1] : "0 0 24 24";
    const widthMatch = cleanSVG.match(/width="([^"]*)"/);
    const heightMatch = cleanSVG.match(/height="([^"]*)"/);
    const width = widthMatch ? widthMatch[1] : "24";
    const height = heightMatch ? heightMatch[1] : "24";
    const contentMatch = cleanSVG.match(/<svg[^>]*>([\s\S]*)<\/svg>/);
    const content = contentMatch ? contentMatch[1].trim() : "";
    let transformedContent = content.replace(/<path /g, "<Path ").replace(/<\/path>/g, "</Path>").replace(/<circle /g, "<Circle ").replace(/<\/circle>/g, "</Circle>").replace(/<rect /g, "<Rect ").replace(/<\/rect>/g, "</Rect>").replace(/<line /g, "<Line ").replace(/<\/line>/g, "</Line>").replace(/<polygon /g, "<Polygon ").replace(/<\/polygon>/g, "</Polygon>").replace(/<polyline /g, "<Polyline ").replace(/<\/polyline>/g, "</Polyline>").replace(/<ellipse /g, "<Ellipse ").replace(/<\/ellipse>/g, "</Ellipse>").replace(/<g /g, "<G ").replace(/<\/g>/g, "</G>");
    transformedContent = transformedContent.replace(/stroke-width=/g, "strokeWidth=").replace(/stroke-linecap=/g, "strokeLinecap=").replace(/stroke-linejoin=/g, "strokeLinejoin=").replace(/fill-rule=/g, "fillRule=").replace(/clip-rule=/g, "clipRule=").replace(/stroke-miterlimit=/g, "strokeMiterlimit=").replace(/stroke-dasharray=/g, "strokeDasharray=").replace(/stroke-dashoffset=/g, "strokeDashoffset=");
    return { viewBox, content: transformedContent, width, height };
  }
  function transformBasicIcon(svg, componentName) {
    const { viewBox, content, width, height } = processSVGContent(svg);
    const contentWithColor = content.replace(/fill="[^"]*"/g, "fill={props.color ?? '#3B3B3B'}");
    return `import * as React from 'react'
import type { SvgProps } from 'react-native-svg'
import Svg, { Path } from 'react-native-svg'

const SvgComponent = (props: SvgProps) => (
  <Svg width={${width}} height={${height}} viewBox="${viewBox}" fill="none" {...props}>
    ${contentWithColor}
  </Svg>
)

export default SvgComponent`;
  }
  function transformIllustratedIcon(svg, componentName) {
    const { viewBox, content, width, height } = processSVGContent(svg);
    const fillMatches = content.match(/fill="([^"]*)"/g) || [];
    const uniqueFills = Array.from(new Set(fillMatches));
    let contentWithColors = content;
    uniqueFills.forEach((fill, index) => {
      const colorVar = index === 0 ? "colorPrimary" : "colorSecondary";
      contentWithColors = contentWithColors.replace(
        new RegExp(fill.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"),
        `fill={disableColor(${colorVar}, disabled)}`
      );
    });
    return `import * as React from 'react'
import Svg, { Path } from 'react-native-svg'
import { useAppIllustratedIconColors } from '../../../hooks'
import { disableColor } from '../../../../theme/utils'
import type { TAppSvgProps } from '../../ui/UIIcon/types'

const SvgComponent = ({ disabled = false, ...props }: TAppSvgProps) => {
  const { colorPrimary, colorSecondary } = useAppIllustratedIconColors()
  return (
    <Svg width={${width}} height={${height}} viewBox="${viewBox}" fill="none" {...props}>
      ${contentWithColors}
    </Svg>
  )
}
export default SvgComponent`;
  }
  function transformSVGToReactNative(svg, componentName, category) {
    if (category === "Basic" /* Basic */) {
      return transformBasicIcon(svg, componentName);
    } else {
      return transformIllustratedIcon(svg, componentName);
    }
  }
  async function batchExportSVGR(componentIds, config) {
    var _a;
    try {
      const exports = [];
      const files = [];
      const total = componentIds.length;
      const basicIcons = [];
      const illustratedIcons = [];
      for (let i = 0; i < componentIds.length; i++) {
        const componentId = componentIds[i];
        const component = await figma.getNodeByIdAsync(componentId);
        if (!component)
          continue;
        const svgString = await exportComponentAsSVG(component);
        const componentName = toComponentName(component.name);
        const category = getIconCategory(component.name);
        const snakeCaseName = toSnakeCaseName(component.name);
        if (category === "Basic" /* Basic */) {
          basicIcons.push({ name: snakeCaseName, componentName });
        } else {
          illustratedIcons.push({ name: snakeCaseName, componentName });
        }
        const reactNativeCode = transformSVGToReactNative(svgString, componentName, category);
        exports.push({
          name: component.name,
          svg: svgString,
          componentName
        });
        files.push({
          fileName: `${componentName}.tsx`,
          content: reactNativeCode
        });
        figma.ui.postMessage({
          type: "export-progress",
          current: i + 1,
          total,
          componentName
        });
      }
      const basicIconNames = basicIcons.map((icon) => `  | '${icon.name}'`).join("\n");
      const illustratedIconNames = illustratedIcons.map((icon) => `  | '${icon.name}'`).join("\n");
      const typesContent = `import type { SvgProps } from 'react-native-svg'
import type { MemoExoticComponent } from 'react'

export type TUIBasicIconName =
${basicIconNames || "  | 'placeholder'"}

export type TUIIllustratedIconName =
${illustratedIconNames || "  | 'placeholder'"}

export type TUIIconName = TUIBasicIconName | TUIIllustratedIconName

export interface TUIBasicIconSet
  extends Record<
    TUIBasicIconName,
    | ((_: SvgProps) => React.JSX.Element)
    | MemoExoticComponent<(_: SvgProps) => React.JSX.Element>
  > {}

export interface TAppSvgProps extends SvgProps {
  disabled?: boolean
}
`;
      files.push({
        fileName: "types.ts",
        content: typesContent
      });
      const componentExports = exports.map((exp) => `export { default as ${exp.componentName} } from './components/${exp.componentName}'`).join("\n");
      const indexContent = `${componentExports}

export type { TUIBasicIconName, TUIIllustratedIconName, TUIIconName, TUIBasicIconSet, TAppSvgProps } from './types'
`;
      files.push({
        fileName: "index.ts",
        content: indexContent
      });
      const readmeContent = `# Exported Icons

Generated with Icon Grid Organizer

## Usage

\`\`\`tsx
import { ${exports.slice(0, 3).map((e) => e.componentName).join(", ")} } from './';

function App() {
  return (
    <View>
      <${(_a = exports[0]) == null ? void 0 : _a.componentName} width={24} height={24} color="#000" />
    </View>
  );
}
\`\`\`

## Configuration

- **Icon mode**: ${config.icon}
- **React Native**: ${config.native}
- **TypeScript**: ${config.typescript}

Total icons: ${exports.length}
`;
      files.push({
        fileName: "README.md",
        content: readmeContent
      });
      const previewFile = files.find(
        (f) => f.fileName.endsWith(".tsx") && f.fileName !== "types.ts" && f.fileName !== "index.ts" && !f.fileName.startsWith("types.") && !f.fileName.startsWith("index.")
      );
      const preview = previewFile ? {
        fileName: previewFile.fileName,
        content: previewFile.content
      } : null;
      console.log("Total files:", files.length);
      console.log("Preview file found:", previewFile ? previewFile.fileName : "none");
      console.log("Preview content length:", previewFile ? previewFile.content.length : 0);
      figma.ui.postMessage({
        type: "export-ready",
        files,
        count: exports.length,
        preview
      });
    } catch (error) {
      console.error("Error in batch export:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      figma.ui.postMessage({
        type: "error",
        message: `Error exporting icons: ${errorMessage}`
      });
    }
  }
  function buildTreeFromComponents(components) {
    const root = [];
    const pathMap = /* @__PURE__ */ new Map();
    for (const component of components) {
      const parts = component.name.split("/");
      let currentPath = "";
      let currentLevel = root;
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i].trim();
        const isLastPart = i === parts.length - 1;
        currentPath = currentPath ? `${currentPath}/${part}` : part;
        let node = currentLevel.find((n) => n.name === part);
        if (!node) {
          node = {
            id: `node-${currentPath.replace(/\//g, "-")}`,
            name: part,
            path: currentPath,
            type: isLastPart ? "icon" : "category",
            children: [],
            componentId: isLastPart ? component.id : void 0
          };
          currentLevel.push(node);
          pathMap.set(currentPath, node);
        }
        if (isLastPart) {
          node.type = "icon";
          node.componentId = component.id;
        } else {
          currentLevel = node.children;
        }
      }
    }
    return root;
  }
  async function attachThumbnailsToTree(tree) {
    for (const node of tree) {
      if (node.type === "icon" && node.componentId) {
        const component = await figma.getNodeByIdAsync(node.componentId);
        if (component) {
          try {
            const iconData = await getIconData(component);
            node.thumbnail = iconData.thumbnail;
          } catch (error) {
            console.error(`Error loading thumbnail for ${node.name}:`, error);
          }
        }
      }
      if (node.children.length > 0) {
        await attachThumbnailsToTree(node.children);
      }
    }
  }
  async function createGridOnCanvas(config, iconIds) {
    try {
      isCreatingGrid = true;
      const totalIcons = iconIds.length;
      const columns = config.columns;
      const rows = Math.ceil(totalIcons / columns);
      await figma.loadFontAsync({ family: "Inter", style: "Regular" });
      let headerFont = { family: "Inter", style: "Bold" };
      try {
        await figma.loadFontAsync({ family: "Gotham", style: "Bold" });
        headerFont = { family: "Gotham", style: "Bold" };
      } catch (error) {
        console.log("Gotham Bold not available, using Inter Bold");
        await figma.loadFontAsync({ family: "Inter", style: "Bold" });
      }
      const mainFrame = findExistingFrame(config.frameName);
      mainFrame.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 }, opacity: 1 }];
      mainFrame.cornerRadius = 16;
      mainFrame.layoutMode = "VERTICAL";
      mainFrame.counterAxisSizingMode = "AUTO";
      mainFrame.primaryAxisSizingMode = "AUTO";
      mainFrame.itemSpacing = config.headerTitle ? 100 : 0;
      mainFrame.paddingLeft = 24;
      mainFrame.paddingRight = 24;
      mainFrame.paddingTop = 24;
      mainFrame.paddingBottom = 24;
      if (config.headerTitle) {
        const headerText = figma.createText();
        headerText.characters = config.headerTitle.toUpperCase();
        headerText.fontSize = 16;
        headerText.fontName = headerFont;
        headerText.fills = [{ type: "SOLID", color: { r: 0.118, g: 0.118, b: 0.118 } }];
        headerText.textAutoResize = "WIDTH_AND_HEIGHT";
        headerText.lineHeight = { value: 24, unit: "PIXELS" };
        mainFrame.appendChild(headerText);
      }
      const gridFrame = figma.createFrame();
      gridFrame.name = "Grid Container";
      gridFrame.layoutMode = "GRID";
      gridFrame.gridRowCount = rows;
      gridFrame.gridColumnCount = columns;
      gridFrame.gridRowGap = config.gap;
      gridFrame.gridColumnGap = config.gap;
      gridFrame.fills = [];
      const cellWidth = 300;
      const iconSize = 24;
      const cellHeight = config.showLabels ? 76 : 48;
      for (let i = 0; i < rows; i++) {
        gridFrame.gridRowSizes[i] = { type: "FIXED", value: cellHeight };
      }
      for (let i = 0; i < columns; i++) {
        gridFrame.gridColumnSizes[i] = { type: "FIXED", value: cellWidth };
      }
      const gridWidth = cellWidth * columns + config.gap * (columns - 1);
      const gridHeight = cellHeight * rows + config.gap * (rows - 1);
      gridFrame.resize(gridWidth, gridHeight);
      for (let i = 0; i < iconIds.length; i++) {
        const iconId = iconIds[i];
        const component = await figma.getNodeByIdAsync(iconId);
        if (!component)
          continue;
        const row = Math.floor(i / columns);
        const col = i % columns;
        const cellFrame = figma.createFrame();
        cellFrame.name = `${component.name}`;
        cellFrame.layoutMode = "HORIZONTAL";
        cellFrame.counterAxisSizingMode = "AUTO";
        cellFrame.primaryAxisSizingMode = "FIXED";
        cellFrame.primaryAxisAlignItems = "MIN";
        cellFrame.counterAxisAlignItems = "CENTER";
        cellFrame.itemSpacing = 12;
        cellFrame.resize(cellWidth, cellFrame.height);
        cellFrame.paddingLeft = 12;
        cellFrame.paddingRight = 12;
        cellFrame.paddingTop = 12;
        cellFrame.paddingBottom = 12;
        cellFrame.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 }, opacity: 1 }];
        cellFrame.strokes = [{ type: "SOLID", color: { r: 0.902, g: 0.902, b: 0.902 } }];
        cellFrame.strokeWeight = 1;
        cellFrame.cornerRadius = 6;
        cellFrame.gridChildHorizontalAlign = "MIN";
        cellFrame.gridChildVerticalAlign = "CENTER";
        let instance;
        if (component.type === "COMPONENT") {
          instance = component.createInstance();
        } else {
          instance = component.clone();
        }
        const currentMaxDimension = Math.max(instance.width, instance.height);
        if (currentMaxDimension !== iconSize) {
          const scale = iconSize / currentMaxDimension;
          instance.resize(instance.width * scale, instance.height * scale);
        }
        cellFrame.appendChild(instance);
        if (config.showLabels) {
          const label = figma.createText();
          label.characters = component.name;
          label.fontSize = 11;
          label.fontName = { family: "Inter", style: "Regular" };
          label.textAlignHorizontal = "LEFT";
          label.fills = [{ type: "SOLID", color: { r: 0.2, g: 0.2, b: 0.2 } }];
          label.textAutoResize = "WIDTH_AND_HEIGHT";
          label.lineHeight = { value: 16, unit: "PIXELS" };
          if (config.enableLabelLinks) {
            let targetComponent = null;
            if (component.type === "INSTANCE") {
              targetComponent = await component.getMainComponentAsync();
            } else if (component.type === "COMPONENT") {
              targetComponent = component;
            }
            if (targetComponent) {
              label.hyperlink = {
                type: "NODE",
                value: targetComponent.id
              };
            }
          }
          cellFrame.appendChild(label);
        }
        const badge = getBadge(component);
        if (badge) {
          try {
            const badgeElement = await createBadgeElement(badge);
            badgeElement.x = cellWidth - badgeElement.width - 43;
            badgeElement.y = -8;
            cellFrame.appendChild(badgeElement);
          } catch (error) {
            console.error("Error creating badge element:", error);
          }
        }
        gridFrame.appendChildAt(cellFrame, row, col);
      }
      mainFrame.appendChild(gridFrame);
      if (mainFrame.x === 0 && mainFrame.y === 0) {
        const selectionBounds = await calculateSelectionBounds(iconIds);
        if (selectionBounds) {
          mainFrame.x = selectionBounds.minX;
          mainFrame.y = selectionBounds.maxY + 100;
        } else {
          mainFrame.x = figma.viewport.center.x - mainFrame.width / 2;
          mainFrame.y = figma.viewport.center.y - mainFrame.height / 2;
        }
      }
      figma.currentPage.selection = [mainFrame];
      figma.viewport.scrollAndZoomIntoView([mainFrame]);
      figma.ui.postMessage({
        type: "grid-created",
        message: `Grid created with ${iconIds.length} icons`
      });
    } catch (error) {
      console.error("Error creating grid:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      figma.ui.postMessage({
        type: "error",
        message: `Error creating grid: ${errorMessage}`
      });
    } finally {
      isCreatingGrid = false;
    }
  }
  async function createTableOnCanvas(config, iconIds) {
    try {
      isCreatingGrid = true;
      await figma.loadFontAsync({ family: "Inter", style: "Regular" });
      await figma.loadFontAsync({ family: "Inter", style: "Bold" });
      const mainFrame = findExistingFrame(config.frameName);
      mainFrame.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 }, opacity: 1 }];
      mainFrame.cornerRadius = 16;
      mainFrame.layoutMode = "VERTICAL";
      mainFrame.counterAxisSizingMode = "AUTO";
      mainFrame.primaryAxisSizingMode = "AUTO";
      mainFrame.itemSpacing = 0;
      mainFrame.paddingLeft = 0;
      mainFrame.paddingRight = 0;
      mainFrame.paddingTop = 0;
      mainFrame.paddingBottom = 0;
      const thumbCol = 60;
      const nameCol = 200;
      const pathCol = 250;
      const sizeCol = 80;
      const totalWidth = thumbCol + nameCol + pathCol + sizeCol;
      const headerRow = figma.createFrame();
      headerRow.name = "Header";
      headerRow.layoutMode = "HORIZONTAL";
      headerRow.counterAxisSizingMode = "AUTO";
      headerRow.primaryAxisSizingMode = "FIXED";
      headerRow.resize(totalWidth, 40);
      headerRow.itemSpacing = 0;
      headerRow.fills = [{ type: "SOLID", color: { r: 0.941, g: 0.941, b: 0.941 } }];
      headerRow.paddingLeft = 0;
      headerRow.paddingRight = 0;
      headerRow.paddingTop = 0;
      headerRow.paddingBottom = 0;
      const headers = [
        { text: "Thumbnail", width: thumbCol },
        { text: "Name", width: nameCol },
        { text: "Path", width: pathCol },
        { text: "Size", width: sizeCol }
      ];
      for (const header of headers) {
        const cell = figma.createFrame();
        cell.name = `Header ${header.text}`;
        cell.layoutMode = "HORIZONTAL";
        cell.counterAxisSizingMode = "FIXED";
        cell.primaryAxisSizingMode = "FIXED";
        cell.resize(header.width, 40);
        cell.fills = [];
        cell.paddingLeft = 8;
        cell.paddingRight = 8;
        cell.paddingTop = 8;
        cell.paddingBottom = 8;
        cell.primaryAxisAlignItems = "CENTER";
        cell.counterAxisAlignItems = "CENTER";
        if (header.text !== "Size") {
          cell.strokes = [{ type: "SOLID", color: { r: 0.878, g: 0.878, b: 0.878 } }];
          cell.strokeWeight = 1;
          cell.strokeAlign = "INSIDE";
          cell.strokeRightWeight = 1;
          cell.strokeLeftWeight = 0;
          cell.strokeTopWeight = 0;
          cell.strokeBottomWeight = 0;
        }
        const headerText = figma.createText();
        headerText.characters = header.text;
        headerText.fontSize = 12;
        headerText.fontName = { family: "Inter", style: "Bold" };
        headerText.fills = [{ type: "SOLID", color: { r: 0.4, g: 0.4, b: 0.4 } }];
        headerText.textAutoResize = "WIDTH_AND_HEIGHT";
        cell.appendChild(headerText);
        headerRow.appendChild(cell);
      }
      mainFrame.appendChild(headerRow);
      for (const iconId of iconIds) {
        const component = await figma.getNodeByIdAsync(iconId);
        if (!component)
          continue;
        const dataRow = figma.createFrame();
        dataRow.name = `Row ${component.name}`;
        dataRow.layoutMode = "HORIZONTAL";
        dataRow.counterAxisSizingMode = "AUTO";
        dataRow.primaryAxisSizingMode = "FIXED";
        dataRow.resize(totalWidth, 48);
        dataRow.itemSpacing = 0;
        dataRow.fills = [];
        dataRow.paddingLeft = 0;
        dataRow.paddingRight = 0;
        dataRow.paddingTop = 0;
        dataRow.paddingBottom = 0;
        dataRow.strokes = [{ type: "SOLID", color: { r: 0.878, g: 0.878, b: 0.878 } }];
        dataRow.strokeWeight = 1;
        dataRow.strokeAlign = "INSIDE";
        dataRow.strokeTopWeight = 1;
        dataRow.strokeLeftWeight = 0;
        dataRow.strokeRightWeight = 0;
        dataRow.strokeBottomWeight = 0;
        const thumbCell = figma.createFrame();
        thumbCell.name = "Thumbnail";
        thumbCell.layoutMode = "HORIZONTAL";
        thumbCell.counterAxisSizingMode = "FIXED";
        thumbCell.primaryAxisSizingMode = "FIXED";
        thumbCell.resize(thumbCol, 48);
        thumbCell.fills = [];
        thumbCell.paddingLeft = 8;
        thumbCell.paddingRight = 8;
        thumbCell.paddingTop = 8;
        thumbCell.paddingBottom = 8;
        thumbCell.primaryAxisAlignItems = "CENTER";
        thumbCell.counterAxisAlignItems = "CENTER";
        thumbCell.strokes = [{ type: "SOLID", color: { r: 0.878, g: 0.878, b: 0.878 } }];
        thumbCell.strokeWeight = 1;
        thumbCell.strokeAlign = "INSIDE";
        thumbCell.strokeRightWeight = 1;
        thumbCell.strokeLeftWeight = 0;
        thumbCell.strokeTopWeight = 0;
        thumbCell.strokeBottomWeight = 0;
        const instance = component.type === "COMPONENT" ? component.createInstance() : component.clone();
        const originalWidth = instance.width;
        const originalHeight = instance.height;
        const scale = 24 / Math.max(originalWidth, originalHeight);
        instance.resize(originalWidth * scale, originalHeight * scale);
        thumbCell.appendChild(instance);
        dataRow.appendChild(thumbCell);
        const nameCell = figma.createFrame();
        nameCell.name = "Name";
        nameCell.layoutMode = "HORIZONTAL";
        nameCell.counterAxisSizingMode = "FIXED";
        nameCell.primaryAxisSizingMode = "FIXED";
        nameCell.resize(nameCol, 48);
        nameCell.fills = [];
        nameCell.paddingLeft = 8;
        nameCell.paddingRight = 8;
        nameCell.paddingTop = 8;
        nameCell.paddingBottom = 8;
        nameCell.primaryAxisAlignItems = "MIN";
        nameCell.counterAxisAlignItems = "CENTER";
        nameCell.strokes = [{ type: "SOLID", color: { r: 0.878, g: 0.878, b: 0.878 } }];
        nameCell.strokeWeight = 1;
        nameCell.strokeAlign = "INSIDE";
        nameCell.strokeRightWeight = 1;
        nameCell.strokeLeftWeight = 0;
        nameCell.strokeTopWeight = 0;
        nameCell.strokeBottomWeight = 0;
        const nameText = figma.createText();
        nameText.characters = component.name.split("/").pop() || component.name;
        nameText.fontSize = 12;
        nameText.fontName = { family: "Inter", style: "Regular" };
        nameText.fills = [{ type: "SOLID", color: { r: 0.118, g: 0.118, b: 0.118 } }];
        nameText.textAutoResize = "WIDTH_AND_HEIGHT";
        if (config.enableLabelLinks) {
          nameText.hyperlink = {
            type: "NODE",
            value: component.id
          };
          nameText.fills = [{ type: "SOLID", color: { r: 0.051, g: 0.6, b: 1 } }];
        }
        nameCell.appendChild(nameText);
        dataRow.appendChild(nameCell);
        const pathCell = figma.createFrame();
        pathCell.name = "Path";
        pathCell.layoutMode = "HORIZONTAL";
        pathCell.counterAxisSizingMode = "FIXED";
        pathCell.primaryAxisSizingMode = "FIXED";
        pathCell.resize(pathCol, 48);
        pathCell.fills = [];
        pathCell.paddingLeft = 8;
        pathCell.paddingRight = 8;
        pathCell.paddingTop = 8;
        pathCell.paddingBottom = 8;
        pathCell.primaryAxisAlignItems = "MIN";
        pathCell.counterAxisAlignItems = "CENTER";
        pathCell.strokes = [{ type: "SOLID", color: { r: 0.878, g: 0.878, b: 0.878 } }];
        pathCell.strokeWeight = 1;
        pathCell.strokeAlign = "INSIDE";
        pathCell.strokeRightWeight = 1;
        pathCell.strokeLeftWeight = 0;
        pathCell.strokeTopWeight = 0;
        pathCell.strokeBottomWeight = 0;
        const pathText = figma.createText();
        pathText.characters = component.name;
        pathText.fontSize = 11;
        pathText.fontName = { family: "Inter", style: "Regular" };
        pathText.fills = [{ type: "SOLID", color: { r: 0.4, g: 0.4, b: 0.4 } }];
        pathText.textAutoResize = "WIDTH_AND_HEIGHT";
        pathCell.appendChild(pathText);
        dataRow.appendChild(pathCell);
        const sizeCell = figma.createFrame();
        sizeCell.name = "Size";
        sizeCell.layoutMode = "HORIZONTAL";
        sizeCell.counterAxisSizingMode = "FIXED";
        sizeCell.primaryAxisSizingMode = "FIXED";
        sizeCell.resize(sizeCol, 48);
        sizeCell.fills = [];
        sizeCell.paddingLeft = 8;
        sizeCell.paddingRight = 8;
        sizeCell.paddingTop = 8;
        sizeCell.paddingBottom = 8;
        sizeCell.primaryAxisAlignItems = "MIN";
        sizeCell.counterAxisAlignItems = "CENTER";
        const sizeText = figma.createText();
        sizeText.characters = `${Math.round(component.width)}x${Math.round(component.height)}`;
        sizeText.fontSize = 11;
        sizeText.fontName = { family: "Inter", style: "Regular" };
        sizeText.fills = [{ type: "SOLID", color: { r: 0.4, g: 0.4, b: 0.4 } }];
        sizeText.textAutoResize = "WIDTH_AND_HEIGHT";
        sizeCell.appendChild(sizeText);
        dataRow.appendChild(sizeCell);
        mainFrame.appendChild(dataRow);
      }
      const selectionBounds = await calculateSelectionBounds(iconIds);
      if (selectionBounds) {
        mainFrame.x = selectionBounds.minX;
        mainFrame.y = selectionBounds.maxY + 100;
      } else {
        const selection = figma.currentPage.selection;
        if (selection.length > 0) {
          mainFrame.x = selection[0].x + selection[0].width + 100;
          mainFrame.y = selection[0].y;
        }
      }
      figma.currentPage.selection = [mainFrame];
      figma.viewport.scrollAndZoomIntoView([mainFrame]);
      figma.ui.postMessage({
        type: "grid-created",
        message: `Table "${config.frameName}" created successfully!`
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error("Error creating table:", error);
      figma.ui.postMessage({
        type: "error",
        message: `Error creating table: ${errorMessage}`
      });
    } finally {
      isCreatingGrid = false;
    }
  }
  function findAllComponents(node, components = []) {
    if (node.type === "COMPONENT") {
      components.push(node);
    }
    if ("children" in node) {
      for (const child of node.children) {
        findAllComponents(child, components);
      }
    }
    return components;
  }
  function selectAllComponentsInPage() {
    try {
      const allComponents = [];
      for (const node of figma.currentPage.children) {
        findAllComponents(node, allComponents);
      }
      if (allComponents.length > 0) {
        figma.currentPage.selection = allComponents;
        figma.viewport.scrollAndZoomIntoView(allComponents);
        figma.ui.postMessage({
          type: "success",
          message: `Selected ${allComponents.length} component${allComponents.length !== 1 ? "s" : ""}`
        });
      } else {
        figma.ui.postMessage({
          type: "error",
          message: "No components found on this page"
        });
      }
    } catch (error) {
      console.error("Error selecting all components:", error);
      figma.ui.postMessage({
        type: "error",
        message: "Error selecting components"
      });
    }
  }
  figma.ui.onmessage = async (msg) => {
    switch (msg.type) {
      case "get-icons":
        try {
          const components = getSelectedComponents();
          if (components.length === 0) {
            figma.ui.postMessage({ type: "no-selection" });
            return;
          }
          const iconsData = [];
          for (const component of components) {
            try {
              const iconData = await getIconData(component);
              iconsData.push(iconData);
            } catch (error) {
              console.error("Skipping component due to error:", component.name);
            }
          }
          const tree = buildTreeFromComponents(components);
          await attachThumbnailsToTree(tree);
          figma.ui.postMessage({
            type: "icons-loaded",
            icons: iconsData,
            tree
          });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error loading icons: ${errorMessage}`
          });
        }
        break;
      case "create-grid":
        await createGridOnCanvas(msg.config, msg.iconIds);
        await saveGridConfigAsPreferences(msg.config);
        break;
      case "create-table":
        await createTableOnCanvas(msg.config, msg.iconIds);
        await saveGridConfigAsPreferences(msg.config);
        break;
      case "select-all-components":
        selectAllComponentsInPage();
        break;
      case "view-icon":
        try {
          const nodeToView = await figma.getNodeByIdAsync(msg.iconId);
          if (nodeToView) {
            figma.currentPage.selection = [nodeToView];
            figma.viewport.scrollAndZoomIntoView([nodeToView]);
            figma.ui.postMessage({
              type: "view-icon-success",
              iconName: nodeToView.name
            });
          } else {
            figma.ui.postMessage({
              type: "error",
              message: `Icon not found with ID: ${msg.iconId}`
            });
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error viewing icon: ${errorMessage}`
          });
        }
        break;
      case "export-svgr":
        await batchExportSVGR(msg.iconIds, msg.config);
        break;
      case "rename-icon":
        try {
          const node = await figma.getNodeByIdAsync(msg.iconId);
          if (node && (node.type === "COMPONENT" || node.type === "INSTANCE")) {
            node.name = msg.newName;
            const components = getSelectedComponents();
            const iconsData = [];
            for (const component of components) {
              try {
                const iconData = await getIconData(component);
                iconsData.push(iconData);
              } catch (error) {
                console.error("Skipping component due to error:", component.name);
              }
            }
            const tree = buildTreeFromComponents(components);
            await attachThumbnailsToTree(tree);
            figma.ui.postMessage({
              type: "icons-loaded",
              icons: iconsData,
              tree
            });
            figma.ui.postMessage({
              type: "success",
              message: `Renamed to "${msg.newName}"`
            });
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error renaming icon: ${errorMessage}`
          });
        }
        break;
      case "bulk-rename":
        try {
          let successCount = 0;
          for (const rename of msg.renames) {
            try {
              const node = await figma.getNodeByIdAsync(rename.iconId);
              if (node && (node.type === "COMPONENT" || node.type === "INSTANCE")) {
                node.name = rename.newName;
                successCount++;
              }
            } catch (error) {
              console.error("Error renaming icon:", rename.iconId, error);
            }
          }
          const components = getSelectedComponents();
          const iconsData = [];
          for (const component of components) {
            try {
              const iconData = await getIconData(component);
              iconsData.push(iconData);
            } catch (error) {
              console.error("Skipping component due to error:", component.name);
            }
          }
          const tree = buildTreeFromComponents(components);
          await attachThumbnailsToTree(tree);
          figma.ui.postMessage({
            type: "icons-loaded",
            icons: iconsData,
            tree
          });
          figma.ui.postMessage({
            type: "success",
            message: `Renamed ${successCount} icon${successCount !== 1 ? "s" : ""}`
          });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error bulk renaming: ${errorMessage}`
          });
        }
        break;
      case "set-badge":
        try {
          const node = await figma.getNodeByIdAsync(msg.iconId);
          if (node && (node.type === "COMPONENT" || node.type === "INSTANCE")) {
            const badge = {
              type: msg.badgeType,
              timestamp: Date.now(),
              color: msg.color
            };
            setBadge(node, badge);
            figma.ui.postMessage({
              type: "success",
              message: `Badge "${msg.badgeType}" added to ${node.name}`
            });
            const components = getSelectedComponents();
            const iconsData = [];
            for (const component of components) {
              try {
                const iconData = await getIconData(component);
                iconsData.push(iconData);
              } catch (error) {
                console.error("Skipping component due to error:", component.name);
              }
            }
            const tree = buildTreeFromComponents(components);
            await attachThumbnailsToTree(tree);
            figma.ui.postMessage({
              type: "icons-loaded",
              icons: iconsData,
              tree
            });
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error setting badge: ${errorMessage}`
          });
        }
        break;
      case "remove-badge":
        try {
          const node = await figma.getNodeByIdAsync(msg.iconId);
          if (node && (node.type === "COMPONENT" || node.type === "INSTANCE")) {
            removeBadge(node);
            figma.ui.postMessage({
              type: "success",
              message: "Badge removed"
            });
            const components = getSelectedComponents();
            const iconsData = [];
            for (const component of components) {
              try {
                const iconData = await getIconData(component);
                iconsData.push(iconData);
              } catch (error) {
                console.error("Skipping component due to error:", component.name);
              }
            }
            const tree = buildTreeFromComponents(components);
            await attachThumbnailsToTree(tree);
            figma.ui.postMessage({
              type: "icons-loaded",
              icons: iconsData,
              tree
            });
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error removing badge: ${errorMessage}`
          });
        }
        break;
      case "bulk-set-badge":
        try {
          let successCount = 0;
          for (const iconId of msg.iconIds) {
            try {
              const node = await figma.getNodeByIdAsync(iconId);
              if (node && (node.type === "COMPONENT" || node.type === "INSTANCE")) {
                const badge = {
                  type: msg.badgeType,
                  timestamp: Date.now(),
                  color: msg.color
                };
                setBadge(node, badge);
                successCount++;
              }
            } catch (error) {
              console.error("Error setting badge for icon:", iconId, error);
            }
          }
          const components = getSelectedComponents();
          const iconsData = [];
          for (const component of components) {
            try {
              const iconData = await getIconData(component);
              iconsData.push(iconData);
            } catch (error) {
              console.error("Skipping component due to error:", component.name);
            }
          }
          const tree = buildTreeFromComponents(components);
          await attachThumbnailsToTree(tree);
          figma.ui.postMessage({
            type: "icons-loaded",
            icons: iconsData,
            tree
          });
          figma.ui.postMessage({
            type: "success",
            message: `Badge applied to ${successCount} icon${successCount !== 1 ? "s" : ""}`
          });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          figma.ui.postMessage({
            type: "error",
            message: `Error bulk setting badges: ${errorMessage}`
          });
        }
        break;
      case "cancel":
        figma.closePlugin();
        break;
      default:
        console.log("Unknown message type:", msg.type);
    }
  };
  figma.ui.postMessage({ type: "init" });
  figma.on("selectionchange", () => {
    if (isCreatingGrid) {
      return;
    }
    const components = getSelectedComponents();
    if (components.length === 0) {
      figma.ui.postMessage({ type: "no-selection" });
      return;
    }
    (async () => {
      try {
        const iconsData = [];
        for (const component of components) {
          try {
            const iconData = await getIconData(component);
            iconsData.push(iconData);
          } catch (error) {
            console.error("Skipping component due to error:", component.name);
          }
        }
        const tree = buildTreeFromComponents(components);
        await attachThumbnailsToTree(tree);
        figma.ui.postMessage({
          type: "icons-loaded",
          icons: iconsData,
          tree
        });
      } catch (error) {
        console.error("Error in selectionchange handler:", error);
      }
    })();
  });
})();
