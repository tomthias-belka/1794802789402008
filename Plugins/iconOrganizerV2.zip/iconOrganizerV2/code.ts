// Icon Grid Organizer - Figma Plugin
// Main plugin code handling Figma API interactions

// Type definitions for messages between UI and plugin
interface BadgeData {
  type: 'new' | 'updated' | 'deprecated' | 'beta' | 'legacy';
  color?: string;
  timestamp?: number;
}

interface IconData {
  id: string;
  name: string;
  thumbnail: Uint8Array;
  badge?: BadgeData;
}

interface GridConfig {
  columns: number;
  gap: number;
  iconSize: number;
  showLabels: boolean;
  labelPosition: 'below' | 'side' | 'none';
  frameName: string;
  headerTitle?: string;
  enableLabelLinks?: boolean;
}

// SVGR Export Configuration
interface SVGRConfig {
  icon: boolean;
  native: boolean;
  typescript: boolean;
  replaceAttrValues?: Record<string, string>;
  svgProps?: Record<string, string>;
}

// SVG Export Data
interface SVGExportData {
  name: string;
  svg: string;
  componentName: string;
}

// Tree Node Structure
interface TreeNode {
  id: string;
  name: string;
  path: string;
  type: 'category' | 'icon';
  children: TreeNode[];
  componentId?: string;
  thumbnail?: Uint8Array;
}

// Thumbnail cache to avoid regenerating on every selection change
const thumbnailCache = new Map<string, Uint8Array>();

// Flag to prevent selectionchange handler during grid creation
let isCreatingGrid = false;

// ===== USER PREFERENCES SYSTEM =====
// Store user's last configuration using clientStorage (local to machine)

interface UserPreferences {
  lastConfig: {
    frameName: string;
    headerTitle: string;
    columns: number;
    gap: number;
    showLabels: boolean;
    enableLabelLinks: boolean;
  };
  lastUsed: number; // Timestamp
}

// Load user preferences from local storage
async function loadUserPreferences(): Promise<UserPreferences | null> {
  try {
    const prefs = await figma.clientStorage.getAsync('userPreferences');
    return prefs as UserPreferences | null;
  } catch (error) {
    console.error('Error loading user preferences:', error);
    return null;
  }
}

// Save user preferences to local storage
async function saveUserPreferences(prefs: UserPreferences): Promise<void> {
  try {
    await figma.clientStorage.setAsync('userPreferences', prefs);
    console.log('User preferences saved');
  } catch (error) {
    console.error('Error saving user preferences:', error);
  }
}

// Save current grid config as preferences
async function saveGridConfigAsPreferences(config: GridConfig): Promise<void> {
  const prefs: UserPreferences = {
    lastConfig: {
      frameName: config.frameName,
      headerTitle: config.headerTitle || '',
      columns: config.columns,
      gap: config.gap,
      showLabels: config.showLabels,
      enableLabelLinks: config.enableLabelLinks || false
    },
    lastUsed: Date.now()
  };
  await saveUserPreferences(prefs);
}

// ===== BADGE CACHE SYSTEM =====
// Centralized cache stored at document level for badge persistence

interface BadgeCacheEntry {
  name: string;           // Component name for reference
  badge: BadgeData;       // Badge data
  lastModified: number;   // Timestamp
}

interface BadgeCache {
  version: 1;
  badges: { [componentId: string]: BadgeCacheEntry };
}

// Load badge cache from document root
function loadBadgeCache(): BadgeCache {
  try {
    const cacheJson = figma.root.getPluginData('badgeCache');
    if (!cacheJson) {
      return { version: 1, badges: {} };
    }
    return JSON.parse(cacheJson) as BadgeCache;
  } catch (error) {
    console.error('Error loading badge cache:', error);
    return { version: 1, badges: {} };
  }
}

// Save badge cache to document root
function saveBadgeCache(cache: BadgeCache): void {
  try {
    figma.root.setPluginData('badgeCache', JSON.stringify(cache));
    console.log('Badge cache saved:', Object.keys(cache.badges).length, 'entries');
  } catch (error) {
    console.error('Error saving badge cache:', error);
  }
}

// Add or update badge in cache
function updateBadgeInCache(nodeId: string, nodeName: string, badge: BadgeData): void {
  const cache = loadBadgeCache();
  cache.badges[nodeId] = {
    name: nodeName,
    badge: badge,
    lastModified: Date.now()
  };
  saveBadgeCache(cache);
}

// Remove badge from cache
function removeBadgeFromCache(nodeId: string): void {
  const cache = loadBadgeCache();
  if (cache.badges[nodeId]) {
    delete cache.badges[nodeId];
    saveBadgeCache(cache);
  }
}

// Get badge from cache by node ID
function getBadgeFromCache(nodeId: string): BadgeData | null {
  const cache = loadBadgeCache();
  const entry = cache.badges[nodeId];
  return entry ? entry.badge : null;
}

// Sync badges from cache to nodes (restore missing badges and clean stale entries)
async function syncBadgesFromCache(): Promise<number> {
  const cache = loadBadgeCache();
  let restoredCount = 0;
  let cleanedCount = 0;
  let cacheModified = false;

  const badgeIds = Object.keys(cache.badges);

  for (const nodeId of badgeIds) {
    try {
      const node = await figma.getNodeByIdAsync(nodeId) as ComponentNode | InstanceNode | null;

      if (node && (node.type === 'COMPONENT' || node.type === 'INSTANCE')) {
        // Node exists - check if it's missing the badge
        const existingBadge = node.getPluginData('badge');
        if (!existingBadge) {
          // Restore badge from cache
          const entry = cache.badges[nodeId];
          node.setPluginData('badge', JSON.stringify(entry.badge));
          restoredCount++;
          console.log(`Restored badge for: ${entry.name}`);
        }
      } else {
        // Node no longer exists - remove stale entry from cache
        delete cache.badges[nodeId];
        cacheModified = true;
        cleanedCount++;
        console.log(`Removed stale badge entry for deleted node: ${nodeId}`);
      }
    } catch (error) {
      console.error(`Error syncing badge for node ${nodeId}:`, error);
    }
  }

  // Save cache only if modified (stale entries removed)
  if (cacheModified) {
    saveBadgeCache(cache);
    console.log(`Cleaned ${cleanedCount} stale entries from badge cache`);
  }

  return restoredCount;
}

// ===== BADGE MANAGEMENT FUNCTIONS =====

// Store badge metadata on component using Plugin Data API
// Also saves to document-level cache for persistence
function setBadge(node: ComponentNode | InstanceNode, badge: BadgeData): void {
  // Save to node
  node.setPluginData('badge', JSON.stringify(badge));
  // Also save to document-level cache
  updateBadgeInCache(node.id, node.name, badge);
}

// Retrieve badge metadata from component
// Falls back to document-level cache if node doesn't have badge data
function getBadge(node: ComponentNode | InstanceNode): BadgeData | null {
  try {
    // First try to get from node
    const badgeJson = node.getPluginData('badge');
    if (badgeJson) {
      return JSON.parse(badgeJson) as BadgeData;
    }

    // Fallback: try to get from document cache
    const cachedBadge = getBadgeFromCache(node.id);
    if (cachedBadge) {
      // Restore badge to node from cache
      node.setPluginData('badge', JSON.stringify(cachedBadge));
      console.log(`Badge restored from cache for: ${node.name}`);
      return cachedBadge;
    }

    return null;
  } catch (error) {
    console.error('Error parsing badge data:', error);
    return null;
  }
}

// Remove badge from component
// Also removes from document-level cache
function removeBadge(node: ComponentNode | InstanceNode): void {
  // Remove from node
  node.setPluginData('badge', '');
  // Also remove from document-level cache
  removeBadgeFromCache(node.id);
}

// Get badge color as RGB
function getBadgeColor(badgeType: BadgeData['type']): RGB {
  const colors: Record<BadgeData['type'], RGB> = {
    'new': { r: 0.078, g: 0.682, b: 0.361 },      // #14AE5C
    'updated': { r: 0.051, g: 0.6, b: 1 },         // #0D99FF
    'deprecated': { r: 0.949, g: 0.282, b: 0.133 }, // #F24822
    'beta': { r: 0.592, g: 0.278, b: 1 },          // #9747FF
    'legacy': { r: 0.4, g: 0.4, b: 0.4 }           // #666666
  };
  return colors[badgeType] || colors['new'];
}

// Create badge visual element for canvas
async function createBadgeElement(badge: BadgeData): Promise<FrameNode> {
  // Load font for badge text
  await figma.loadFontAsync({ family: "Inter", style: "Bold" });

  // Create badge frame (background)
  const badgeFrame = figma.createFrame();
  badgeFrame.name = 'Badge';
  badgeFrame.resize(40, 16);
  badgeFrame.fills = [{
    type: 'SOLID',
    color: badge.color ? hexToRgb(badge.color) : getBadgeColor(badge.type)
  }];
  badgeFrame.cornerRadius = 4;
  badgeFrame.layoutMode = 'HORIZONTAL';
  badgeFrame.paddingLeft = 6;
  badgeFrame.paddingRight = 6;
  badgeFrame.primaryAxisAlignItems = 'CENTER';
  badgeFrame.counterAxisAlignItems = 'CENTER';

  // Create badge text
  const badgeText = figma.createText();
  badgeText.characters = badge.type.toUpperCase();
  badgeText.fontSize = 9;
  badgeText.fontName = { family: "Inter", style: "Bold" };
  badgeText.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
  badgeText.textAutoResize = "WIDTH_AND_HEIGHT";

  badgeFrame.appendChild(badgeText);

  return badgeFrame;
}

// Helper: Convert hex color to RGB
function hexToRgb(hex: string): RGB {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16) / 255,
    g: parseInt(result[2], 16) / 255,
    b: parseInt(result[3], 16) / 255
  } : { r: 0, g: 0, b: 0 };
}

// Show the plugin UI with larger responsive dimensions
figma.showUI(__html__, {
  width: 900,
  height: 700,
  themeColors: true
});

// Plugin startup: sync badges and load user preferences
(async () => {
  // Sync badges from cache
  const restoredCount = await syncBadgesFromCache();
  if (restoredCount > 0) {
    figma.notify(`✅ Restored ${restoredCount} badge(s) from cache`);
  }

  // Log cache status
  const cache = loadBadgeCache();
  console.log(`Badge cache loaded: ${Object.keys(cache.badges).length} entries`);

  // Load and send user preferences to UI
  const userPrefs = await loadUserPreferences();
  if (userPrefs) {
    figma.ui.postMessage({
      type: 'load-preferences',
      preferences: userPrefs.lastConfig
    });
    console.log('User preferences loaded:', userPrefs.lastConfig.frameName);
  }
})();

// Function to find existing frame by name or create new one
function findExistingFrame(frameName: string): FrameNode {
  // Search for existing frame with the same name in the current page
  const existingFrames = figma.currentPage.findAll(node =>
    node.type === 'FRAME' && node.name === frameName
  ) as FrameNode[];

  // Notify user if multiple frames with same name exist
  if (existingFrames.length > 1) {
    figma.notify(`Warning: ${existingFrames.length} frames named "${frameName}" found. Reusing the first one.`);
  }

  if (existingFrames.length > 0) {
    // Use the first matching frame
    const frame = existingFrames[0];

    // Remove all existing children to start fresh
    const children = [...frame.children]; // Create copy to avoid mutation during iteration
    children.forEach(child => child.remove());

    console.log(`Reusing existing frame: "${frameName}"`);
    return frame;
  }

  // Create new frame if not found
  const newFrame = figma.createFrame();
  newFrame.name = frameName;
  console.log(`Creating new frame: "${frameName}"`);
  return newFrame;
}

// Function to calculate bounding box of original icon components
async function calculateSelectionBounds(iconIds: string[]): Promise<{ minX: number; minY: number; maxX: number; maxY: number } | null> {
  if (iconIds.length === 0) return null;

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const iconId of iconIds) {
    const node = await figma.getNodeByIdAsync(iconId) as SceneNode | null;
    if (node && 'absoluteBoundingBox' in node && node.absoluteBoundingBox) {
      const bounds = node.absoluteBoundingBox;
      minX = Math.min(minX, bounds.x);
      minY = Math.min(minY, bounds.y);
      maxX = Math.max(maxX, bounds.x + bounds.width);
      maxY = Math.max(maxY, bounds.y + bounds.height);
    }
  }

  if (minX === Infinity) return null;

  return { minX, minY, maxX, maxY };
}

// Function to get selected components and instances
function getSelectedComponents(): (ComponentNode | InstanceNode)[] {
  const selection = figma.currentPage.selection;

  console.log('=== SELECTION DEBUG ===');
  console.log('Total selection count:', selection.length);
  console.log('Selection types:', selection.map(n => `${n.name} (${n.type})`).join(', '));

  const filtered = selection.filter(node =>
    node.type === 'COMPONENT' || node.type === 'INSTANCE'
  ) as (ComponentNode | InstanceNode)[];

  console.log('Filtered components/instances:', filtered.length);
  console.log('======================');

  return filtered;
}

// Function to generate thumbnail and icon data (with caching)
async function getIconData(component: ComponentNode | InstanceNode): Promise<IconData> {
  try {
    // Check cache first
    let thumbnail = thumbnailCache.get(component.id);

    // Generate thumbnail if not cached
    if (!thumbnail) {
      thumbnail = await component.exportAsync({
        format: 'PNG',
        constraint: { type: 'SCALE', value: 2 }
      });
      // Store in cache
      thumbnailCache.set(component.id, thumbnail);
    }

    // Get badge metadata
    const badge = getBadge(component);

    return {
      id: component.id,
      name: component.name,
      thumbnail: thumbnail,
      badge: badge || undefined
    };
  } catch (error) {
    console.error('Error generating thumbnail for', component.name, error);
    throw error;
  }
}

// Function to convert component name to valid React component name
// Enum for icon category
enum IconCategory {
  Basic = 'Basic',
  Illustrated = 'Illustrated'
}

// Function to determine icon category from name
function getIconCategory(name: string): IconCategory {
  const lowerName = name.toLowerCase();
  if (lowerName.startsWith('basic/') || lowerName.includes('/basic/')) {
    return IconCategory.Basic;
  }
  if (lowerName.startsWith('illustrated/') || lowerName.startsWith('colored/') || lowerName.includes('/illustrated/') || lowerName.includes('/colored/')) {
    return IconCategory.Illustrated;
  }
  // Default to Basic for backward compatibility
  return IconCategory.Basic;
}

function toComponentName(name: string): string {
  // Remove special characters and convert to PascalCase
  // Example: "icon/brand/fill/rounded/download" → "IconBrandFillRoundedDownload"
  return name
    .split('/')
    .map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
    .join('')
    .replace(/[^a-zA-Z0-9]/g, '');
}

// Function to convert component name to snake_case for type union
function toSnakeCaseName(name: string): string {
  // Example: "Basic/map/position/ios" → "basic_map_position_ios"
  return name
    .toLowerCase()
    .replace(/\//g, '_')
    .replace(/[^a-z0-9_]/g, '');
}

// Function to export component as SVG string
async function exportComponentAsSVG(component: ComponentNode | InstanceNode): Promise<string> {
  try {
    const svgData = await component.exportAsync({
      format: 'SVG',
      svgIdAttribute: false,
      svgOutlineText: true
    });

    // Convert Uint8Array to string
    const svgString = String.fromCharCode.apply(null, Array.from(svgData));
    return svgString;
  } catch (error) {
    console.error('Error exporting SVG for', component.name, error);
    throw error;
  }
}

// Helper function to process SVG content
function processSVGContent(svg: string): { viewBox: string; content: string; width: string; height: string } {
  // Remove XML declaration
  let cleanSVG = svg.replace(/<\?xml[^>]*\?>/g, '');

  // Extract viewBox and dimensions from SVG tag
  const viewBoxMatch = cleanSVG.match(/viewBox="([^"]*)"/);
  const viewBox = viewBoxMatch ? viewBoxMatch[1] : '0 0 24 24';

  const widthMatch = cleanSVG.match(/width="([^"]*)"/);
  const heightMatch = cleanSVG.match(/height="([^"]*)"/);
  const width = widthMatch ? widthMatch[1] : '24';
  const height = heightMatch ? heightMatch[1] : '24';

  // Extract SVG content (children)
  const contentMatch = cleanSVG.match(/<svg[^>]*>([\s\S]*)<\/svg>/);
  const content = contentMatch ? contentMatch[1].trim() : '';

  // Transform SVG elements to React Native Svg components
  let transformedContent = content
    .replace(/<path /g, '<Path ')
    .replace(/<\/path>/g, '</Path>')
    .replace(/<circle /g, '<Circle ')
    .replace(/<\/circle>/g, '</Circle>')
    .replace(/<rect /g, '<Rect ')
    .replace(/<\/rect>/g, '</Rect>')
    .replace(/<line /g, '<Line ')
    .replace(/<\/line>/g, '</Line>')
    .replace(/<polygon /g, '<Polygon ')
    .replace(/<\/polygon>/g, '</Polygon>')
    .replace(/<polyline /g, '<Polyline ')
    .replace(/<\/polyline>/g, '</Polyline>')
    .replace(/<ellipse /g, '<Ellipse ')
    .replace(/<\/ellipse>/g, '</Ellipse>')
    .replace(/<g /g, '<G ')
    .replace(/<\/g>/g, '</G>');

  // Transform attributes to camelCase
  transformedContent = transformedContent
    .replace(/stroke-width=/g, 'strokeWidth=')
    .replace(/stroke-linecap=/g, 'strokeLinecap=')
    .replace(/stroke-linejoin=/g, 'strokeLinejoin=')
    .replace(/fill-rule=/g, 'fillRule=')
    .replace(/clip-rule=/g, 'clipRule=')
    .replace(/stroke-miterlimit=/g, 'strokeMiterlimit=')
    .replace(/stroke-dasharray=/g, 'strokeDasharray=')
    .replace(/stroke-dashoffset=/g, 'strokeDashoffset=');

  return { viewBox, content: transformedContent, width, height };
}

// Transform Basic icon - uses simple color prop pattern
function transformBasicIcon(svg: string, componentName: string): string {
  const { viewBox, content, width, height } = processSVGContent(svg);

  // Replace fill colors with prop color pattern
  const contentWithColor = content.replace(/fill="[^"]*"/g, 'fill={props.color ?? \'#3B3B3B\'}');

  return `import * as React from 'react'
import type { SvgProps } from 'react-native-svg'
import Svg, { Path } from 'react-native-svg'

const SvgComponent = (props: SvgProps) => (
  <Svg width={${width}} height={${height}} viewBox="${viewBox}" fill="none" {...props}>
    ${contentWithColor}
  </Svg>
)

export default SvgComponent`;
}

// Transform Illustrated icon - uses hooks and disabled state
function transformIllustratedIcon(svg: string, componentName: string): string {
  const { viewBox, content, width, height } = processSVGContent(svg);

  // Extract unique fill colors to determine primary/secondary
  const fillMatches = content.match(/fill="([^"]*)"/g) || [];
  const uniqueFills = Array.from(new Set(fillMatches));

  // Replace fills with color management
  let contentWithColors = content;
  uniqueFills.forEach((fill, index) => {
    const colorVar = index === 0 ? 'colorPrimary' : 'colorSecondary';
    contentWithColors = contentWithColors.replace(
      new RegExp(fill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'),
      `fill={disableColor(${colorVar}, disabled)}`
    );
  });

  return `import * as React from 'react'
import Svg, { Path } from 'react-native-svg'
import { useAppIllustratedIconColors } from '../../../hooks'
import { disableColor } from '../../../../theme/utils'
import type { TAppSvgProps } from '../../ui/UIIcon/types'

const SvgComponent = ({ disabled = false, ...props }: TAppSvgProps) => {
  const { colorPrimary, colorSecondary } = useAppIllustratedIconColors()
  return (
    <Svg width={${width}} height={${height}} viewBox="${viewBox}" fill="none" {...props}>
      ${contentWithColors}
    </Svg>
  )
}
export default SvgComponent`;
}

// Main function to transform SVG based on category
function transformSVGToReactNative(svg: string, componentName: string, category: IconCategory): string {
  if (category === IconCategory.Basic) {
    return transformBasicIcon(svg, componentName);
  } else {
    return transformIllustratedIcon(svg, componentName);
  }
}

// Interface for export file data
interface ExportFileData {
  fileName: string;
  content: string;
}

// Function to batch export components as SVGR React Native components
async function batchExportSVGR(componentIds: string[], config: SVGRConfig) {
  try {
    const exports: SVGExportData[] = [];
    const files: ExportFileData[] = [];
    const total = componentIds.length;
    const basicIcons: { name: string; componentName: string }[] = [];
    const illustratedIcons: { name: string; componentName: string }[] = [];

    for (let i = 0; i < componentIds.length; i++) {
      const componentId = componentIds[i];
      const component = await figma.getNodeByIdAsync(componentId) as ComponentNode | InstanceNode | null;

      if (!component) continue;

      // Export as SVG
      const svgString = await exportComponentAsSVG(component);

      // Generate component name
      const componentName = toComponentName(component.name);

      // Determine icon category
      const category = getIconCategory(component.name);

      // Track icons by category
      const snakeCaseName = toSnakeCaseName(component.name);
      if (category === IconCategory.Basic) {
        basicIcons.push({ name: snakeCaseName, componentName });
      } else {
        illustratedIcons.push({ name: snakeCaseName, componentName });
      }

      // Transform to React Native component
      const reactNativeCode = transformSVGToReactNative(svgString, componentName, category);

      exports.push({
        name: component.name,
        svg: svgString,
        componentName: componentName
      });

      // Add to files array
      files.push({
        fileName: `${componentName}.tsx`,
        content: reactNativeCode
      });

      // Send progress update
      figma.ui.postMessage({
        type: 'export-progress',
        current: i + 1,
        total: total,
        componentName: componentName
      });
    }

    // Generate types.ts
    const basicIconNames = basicIcons.map(icon => `  | '${icon.name}'`).join('\n');
    const illustratedIconNames = illustratedIcons.map(icon => `  | '${icon.name}'`).join('\n');

    const typesContent = `import type { SvgProps } from 'react-native-svg'
import type { MemoExoticComponent } from 'react'

export type TUIBasicIconName =
${basicIconNames || "  | 'placeholder'"}

export type TUIIllustratedIconName =
${illustratedIconNames || "  | 'placeholder'"}

export type TUIIconName = TUIBasicIconName | TUIIllustratedIconName

export interface TUIBasicIconSet
  extends Record<
    TUIBasicIconName,
    | ((_: SvgProps) => React.JSX.Element)
    | MemoExoticComponent<(_: SvgProps) => React.JSX.Element>
  > {}

export interface TAppSvgProps extends SvgProps {
  disabled?: boolean
}
`;

    files.push({
      fileName: 'types.ts',
      content: typesContent
    });

    // Generate index.ts with component exports and type exports
    const componentExports = exports
      .map(exp => `export { default as ${exp.componentName} } from './components/${exp.componentName}'`)
      .join('\n');

    const indexContent = `${componentExports}

export type { TUIBasicIconName, TUIIllustratedIconName, TUIIconName, TUIBasicIconSet, TAppSvgProps } from './types'
`;

    files.push({
      fileName: 'index.ts',
      content: indexContent
    });

    // Generate README.md
    const readmeContent = `# Exported Icons

Generated with Icon Grid Organizer

## Usage

\`\`\`tsx
import { ${exports.slice(0, 3).map(e => e.componentName).join(', ')} } from './';

function App() {
  return (
    <View>
      <${exports[0]?.componentName} width={24} height={24} color="#000" />
    </View>
  );
}
\`\`\`

## Configuration

- **Icon mode**: ${config.icon}
- **React Native**: ${config.native}
- **TypeScript**: ${config.typescript}

Total icons: ${exports.length}
`;

    files.push({
      fileName: 'README.md',
      content: readmeContent
    });

    // Get preview of first icon component (not types.ts or index.ts)
    const previewFile = files.find(f =>
      f.fileName.endsWith('.tsx') &&
      f.fileName !== 'types.ts' &&
      f.fileName !== 'index.ts' &&
      !f.fileName.startsWith('types.') &&
      !f.fileName.startsWith('index.')
    );
    const preview = previewFile ? {
      fileName: previewFile.fileName,
      content: previewFile.content
    } : null;

    console.log('Total files:', files.length);
    console.log('Preview file found:', previewFile ? previewFile.fileName : 'none');
    console.log('Preview content length:', previewFile ? previewFile.content.length : 0);

    // Send all files to UI for ZIP creation
    figma.ui.postMessage({
      type: 'export-ready',
      files: files,
      count: exports.length,
      preview: preview
    });

  } catch (error) {
    console.error('Error in batch export:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    figma.ui.postMessage({
      type: 'error',
      message: `Error exporting icons: ${errorMessage}`
    });
  }
}

// Function to build tree structure from component naming
function buildTreeFromComponents(components: (ComponentNode | InstanceNode)[]): TreeNode[] {
  const root: TreeNode[] = [];
  const pathMap = new Map<string, TreeNode>();

  for (const component of components) {
    const parts = component.name.split('/');
    let currentPath = '';
    let currentLevel = root;

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i].trim();
      const isLastPart = i === parts.length - 1;
      currentPath = currentPath ? `${currentPath}/${part}` : part;

      // Check if node already exists at this level
      let node = currentLevel.find(n => n.name === part);

      if (!node) {
        // Create new node
        node = {
          id: `node-${currentPath.replace(/\//g, '-')}`,
          name: part,
          path: currentPath,
          type: isLastPart ? 'icon' : 'category',
          children: [],
          componentId: isLastPart ? component.id : undefined
        };

        currentLevel.push(node);
        pathMap.set(currentPath, node);
      }

      // If this is the last part (actual icon), update node
      if (isLastPart) {
        node.type = 'icon';
        node.componentId = component.id;
      } else {
        // Move to next level
        currentLevel = node.children;
      }
    }
  }

  return root;
}

// Function to attach thumbnails to tree nodes
async function attachThumbnailsToTree(tree: TreeNode[]): Promise<void> {
  for (const node of tree) {
    if (node.type === 'icon' && node.componentId) {
      const component = await figma.getNodeByIdAsync(node.componentId) as ComponentNode | InstanceNode | null;
      if (component) {
        try {
          const iconData = await getIconData(component);
          node.thumbnail = iconData.thumbnail;
        } catch (error) {
          console.error(`Error loading thumbnail for ${node.name}:`, error);
        }
      }
    }

    if (node.children.length > 0) {
      await attachThumbnailsToTree(node.children);
    }
  }
}

// Function to get all icons from tree (flatten)
function flattenTree(tree: TreeNode[]): TreeNode[] {
  const icons: TreeNode[] = [];

  function traverse(nodes: TreeNode[]) {
    for (const node of nodes) {
      if (node.type === 'icon') {
        icons.push(node);
      }
      if (node.children.length > 0) {
        traverse(node.children);
      }
    }
  }

  traverse(tree);
  return icons;
}

// Function to search tree nodes
function searchTree(tree: TreeNode[], query: string): TreeNode[] {
  const results: TreeNode[] = [];
  const lowerQuery = query.toLowerCase();

  function traverse(nodes: TreeNode[]) {
    for (const node of nodes) {
      // Check if node name or path matches query
      if (
        node.name.toLowerCase().includes(lowerQuery) ||
        node.path.toLowerCase().includes(lowerQuery)
      ) {
        results.push(node);
      }

      if (node.children.length > 0) {
        traverse(node.children);
      }
    }
  }

  traverse(tree);
  return results;
}

// Function to create grid on canvas using native GRID layout
async function createGridOnCanvas(config: GridConfig, iconIds: string[]) {
  try {
    // Set flag to prevent selectionchange handler interference
    isCreatingGrid = true;

    // Calculate grid dimensions
    const totalIcons = iconIds.length;
    const columns = config.columns;
    const rows = Math.ceil(totalIcons / columns);

    // Load fonts (Inter Regular for labels, Gotham Bold for header)
    await figma.loadFontAsync({ family: "Inter", style: "Regular" });

    // Try to load Gotham Bold for header, fallback to Inter Bold if not available
    let headerFont = { family: "Inter", style: "Bold" };
    try {
      await figma.loadFontAsync({ family: "Gotham", style: "Bold" });
      headerFont = { family: "Gotham", style: "Bold" };
    } catch (error) {
      console.log('Gotham Bold not available, using Inter Bold');
      await figma.loadFontAsync({ family: "Inter", style: "Bold" });
    }

    // Find or create main frame
    const mainFrame = findExistingFrame(config.frameName);

    // Main frame styling (white background, rounded corners)
    mainFrame.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: 1 }];
    mainFrame.cornerRadius = 16;
    mainFrame.layoutMode = "VERTICAL";
    mainFrame.counterAxisSizingMode = "AUTO";
    mainFrame.primaryAxisSizingMode = "AUTO";
    mainFrame.itemSpacing = config.headerTitle ? 100 : 0; // Gap between header and grid sections
    mainFrame.paddingLeft = 24;
    mainFrame.paddingRight = 24;
    mainFrame.paddingTop = 24;
    mainFrame.paddingBottom = 24;

    // Create header with title (only if headerTitle is provided)
    if (config.headerTitle) {
      const headerText = figma.createText();
      headerText.characters = config.headerTitle.toUpperCase();
      headerText.fontSize = 16;
      headerText.fontName = headerFont;
      headerText.fills = [{ type: 'SOLID', color: { r: 0.118, g: 0.118, b: 0.118 } }]; // #1e1e1e
      headerText.textAutoResize = "WIDTH_AND_HEIGHT";
      headerText.lineHeight = { value: 24, unit: 'PIXELS' };
      mainFrame.appendChild(headerText);
    }

    // Create grid container with GRID layout
    const gridFrame = figma.createFrame();
    gridFrame.name = "Grid Container";
    gridFrame.layoutMode = "GRID";
    gridFrame.gridRowCount = rows;
    gridFrame.gridColumnCount = columns;
    gridFrame.gridRowGap = config.gap;
    gridFrame.gridColumnGap = config.gap;

    // Grid frame styling (transparent background)
    gridFrame.fills = [];

    // NEW DESIGN: Cell width 300px (increased from 240px for longer names), Icon size 24px
    const cellWidth = 300;
    const iconSize = 24;

    // Calculate cell height: 12px padding top + 24px icon + 12px gap + ~16px label + 12px padding bottom
    const cellHeight = config.showLabels ? 76 : 48;

    // Configure track sizes
    for (let i = 0; i < rows; i++) {
      gridFrame.gridRowSizes[i] = { type: 'FIXED', value: cellHeight };
    }
    for (let i = 0; i < columns; i++) {
      gridFrame.gridColumnSizes[i] = { type: 'FIXED', value: cellWidth };
    }

    // Set explicit grid frame size
    const gridWidth = (cellWidth * columns) + (config.gap * (columns - 1));
    const gridHeight = (cellHeight * rows) + (config.gap * (rows - 1));
    gridFrame.resize(gridWidth, gridHeight);

    // Add all icons to the grid
    for (let i = 0; i < iconIds.length; i++) {
      const iconId = iconIds[i];
      const component = await figma.getNodeByIdAsync(iconId) as ComponentNode | InstanceNode | null;

      if (!component) continue;

      // Calculate grid position
      const row = Math.floor(i / columns);
      const col = i % columns;

      // Create container for icon + label (NEW DESIGN from node 18-13827)
      const cellFrame = figma.createFrame();
      cellFrame.name = `${component.name}`;

      // Layout: HORIZONTAL with gap 12px (icon beside label)
      cellFrame.layoutMode = "HORIZONTAL";
      cellFrame.counterAxisSizingMode = "AUTO"; // Height: Hug
      cellFrame.primaryAxisSizingMode = "FIXED"; // Width: Fixed 240px
      cellFrame.primaryAxisAlignItems = "MIN"; // Align items to left (start)
      cellFrame.counterAxisAlignItems = "CENTER"; // Vertical center alignment
      cellFrame.itemSpacing = 12; // Gap between icon and label

      // Set fixed width to 240px
      cellFrame.resize(cellWidth, cellFrame.height);

      // Padding: 12px on all sides
      cellFrame.paddingLeft = 12;
      cellFrame.paddingRight = 12;
      cellFrame.paddingTop = 12;
      cellFrame.paddingBottom = 12;

      // Background: white (#ffffff)
      cellFrame.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: 1 }];

      // Border: 1px solid #e6e6e6
      cellFrame.strokes = [{ type: 'SOLID', color: { r: 0.902, g: 0.902, b: 0.902 } }];
      cellFrame.strokeWeight = 1;

      // Border-radius: 6px
      cellFrame.cornerRadius = 6;

      // Grid child alignment (LEFT alignment in grid cell)
      cellFrame.gridChildHorizontalAlign = 'MIN'; // Align to left
      cellFrame.gridChildVerticalAlign = 'CENTER'; // Center vertically

      // Create instance of the component
      let instance: InstanceNode;
      if (component.type === 'COMPONENT') {
        instance = component.createInstance();
      } else {
        // If it's already an instance, clone it
        instance = component.clone();
      }

      // Resize instance to 24x24px (maintain aspect ratio)
      const currentMaxDimension = Math.max(instance.width, instance.height);
      if (currentMaxDimension !== iconSize) {
        const scale = iconSize / currentMaxDimension;
        instance.resize(instance.width * scale, instance.height * scale);
      }

      cellFrame.appendChild(instance);

      // Add label (Inter Regular 11px, color #333333)
      if (config.showLabels) {
        const label = figma.createText();
        label.characters = component.name;
        label.fontSize = 11;
        label.fontName = { family: "Inter", style: "Regular" };
        label.textAlignHorizontal = "LEFT";
        label.fills = [{ type: 'SOLID', color: { r: 0.2, g: 0.2, b: 0.2 } }]; // #333333
        label.textAutoResize = "WIDTH_AND_HEIGHT";
        label.lineHeight = { value: 16, unit: 'PIXELS' }; // line-height normal

        // Add hyperlink to main component if enabled
        if (config.enableLabelLinks) {
          let targetComponent: ComponentNode | null = null;

          if (component.type === 'INSTANCE') {
            targetComponent = await component.getMainComponentAsync();
          } else if (component.type === 'COMPONENT') {
            targetComponent = component;
          }

          if (targetComponent) {
            label.hyperlink = {
              type: 'NODE',
              value: targetComponent.id
            };
          }
        }

        cellFrame.appendChild(label);
      }

      // Add badge if present (positioned above card, aligned right)
      const badge = getBadge(component);
      if (badge) {
        try {
          const badgeElement = await createBadgeElement(badge);
          // Position badge absolutely: above the card border (top: -8px) and aligned to right
          badgeElement.x = cellWidth - badgeElement.width - 43; // Right edge minus badge width minus right margin (43px from right)
          badgeElement.y = -8; // Above the card border
          cellFrame.appendChild(badgeElement);
        } catch (error) {
          console.error('Error creating badge element:', error);
        }
      }

      // CRITICAL: Use appendChildAt to position in specific grid cell
      gridFrame.appendChildAt(cellFrame, row, col);
    }

    // Append grid to main frame
    mainFrame.appendChild(gridFrame);

    // Position main frame BELOW the original icons selection (only if newly created)
    if (mainFrame.x === 0 && mainFrame.y === 0) {
      const selectionBounds = await calculateSelectionBounds(iconIds);
      if (selectionBounds) {
        // Position below the original icons with 100px margin
        mainFrame.x = selectionBounds.minX;
        mainFrame.y = selectionBounds.maxY + 100;
      } else {
        // Fallback to viewport center if bounds calculation fails
        mainFrame.x = figma.viewport.center.x - mainFrame.width / 2;
        mainFrame.y = figma.viewport.center.y - mainFrame.height / 2;
      }
    }

    // Select the main frame and zoom to it
    figma.currentPage.selection = [mainFrame];
    figma.viewport.scrollAndZoomIntoView([mainFrame]);

    // Send success message to UI
    figma.ui.postMessage({
      type: 'grid-created',
      message: `Grid created with ${iconIds.length} icons`
    });

  } catch (error) {
    console.error('Error creating grid:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    figma.ui.postMessage({
      type: 'error',
      message: `Error creating grid: ${errorMessage}`
    });
  } finally {
    // Reset flag after grid creation is complete
    isCreatingGrid = false;
  }
}

// Function to create table on canvas using AUTO LAYOUT
async function createTableOnCanvas(config: GridConfig, iconIds: string[]) {
  try {
    isCreatingGrid = true;

    // Load fonts
    await figma.loadFontAsync({ family: "Inter", style: "Regular" });
    await figma.loadFontAsync({ family: "Inter", style: "Bold" });

    // Find or create main frame
    const mainFrame = findExistingFrame(config.frameName);

    // Main frame styling
    mainFrame.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: 1 }];
    mainFrame.cornerRadius = 16;
    mainFrame.layoutMode = "VERTICAL";
    mainFrame.counterAxisSizingMode = "AUTO";
    mainFrame.primaryAxisSizingMode = "AUTO";
    mainFrame.itemSpacing = 0; // No gap between rows
    mainFrame.paddingLeft = 0;
    mainFrame.paddingRight = 0;
    mainFrame.paddingTop = 0;
    mainFrame.paddingBottom = 0;

    // Table column widths
    const thumbCol = 60;
    const nameCol = 200;
    const pathCol = 250;
    const sizeCol = 80;
    const totalWidth = thumbCol + nameCol + pathCol + sizeCol;

    // Create header row
    const headerRow = figma.createFrame();
    headerRow.name = "Header";
    headerRow.layoutMode = "HORIZONTAL";
    headerRow.counterAxisSizingMode = "AUTO";
    headerRow.primaryAxisSizingMode = "FIXED";
    headerRow.resize(totalWidth, 40);
    headerRow.itemSpacing = 0;
    headerRow.fills = [{ type: 'SOLID', color: { r: 0.941, g: 0.941, b: 0.941 } }]; // #F0F0F0
    headerRow.paddingLeft = 0;
    headerRow.paddingRight = 0;
    headerRow.paddingTop = 0;
    headerRow.paddingBottom = 0;

    // Header cells
    const headers = [
      { text: 'Thumbnail', width: thumbCol },
      { text: 'Name', width: nameCol },
      { text: 'Path', width: pathCol },
      { text: 'Size', width: sizeCol }
    ];

    for (const header of headers) {
      const cell = figma.createFrame();
      cell.name = `Header ${header.text}`;
      cell.layoutMode = "HORIZONTAL";
      cell.counterAxisSizingMode = "FIXED";
      cell.primaryAxisSizingMode = "FIXED";
      cell.resize(header.width, 40);
      cell.fills = [];
      cell.paddingLeft = 8;
      cell.paddingRight = 8;
      cell.paddingTop = 8;
      cell.paddingBottom = 8;
      cell.primaryAxisAlignItems = "CENTER";
      cell.counterAxisAlignItems = "CENTER";

      // Add stroke on right except last column
      if (header.text !== 'Size') {
        cell.strokes = [{ type: 'SOLID', color: { r: 0.878, g: 0.878, b: 0.878 } }]; // #E0E0E0
        cell.strokeWeight = 1;
        cell.strokeAlign = "INSIDE";
        cell.strokeRightWeight = 1;
        cell.strokeLeftWeight = 0;
        cell.strokeTopWeight = 0;
        cell.strokeBottomWeight = 0;
      }

      const headerText = figma.createText();
      headerText.characters = header.text;
      headerText.fontSize = 12;
      headerText.fontName = { family: "Inter", style: "Bold" };
      headerText.fills = [{ type: 'SOLID', color: { r: 0.4, g: 0.4, b: 0.4 } }];
      headerText.textAutoResize = "WIDTH_AND_HEIGHT";
      cell.appendChild(headerText);

      headerRow.appendChild(cell);
    }

    mainFrame.appendChild(headerRow);

    // Create data rows
    for (const iconId of iconIds) {
      const component = await figma.getNodeByIdAsync(iconId) as ComponentNode | InstanceNode | null;
      if (!component) continue;

      // Data row
      const dataRow = figma.createFrame();
      dataRow.name = `Row ${component.name}`;
      dataRow.layoutMode = "HORIZONTAL";
      dataRow.counterAxisSizingMode = "AUTO";
      dataRow.primaryAxisSizingMode = "FIXED";
      dataRow.resize(totalWidth, 48);
      dataRow.itemSpacing = 0;
      dataRow.fills = [];
      dataRow.paddingLeft = 0;
      dataRow.paddingRight = 0;
      dataRow.paddingTop = 0;
      dataRow.paddingBottom = 0;

      // Add top border to row
      dataRow.strokes = [{ type: 'SOLID', color: { r: 0.878, g: 0.878, b: 0.878 } }]; // #E0E0E0
      dataRow.strokeWeight = 1;
      dataRow.strokeAlign = "INSIDE";
      dataRow.strokeTopWeight = 1;
      dataRow.strokeLeftWeight = 0;
      dataRow.strokeRightWeight = 0;
      dataRow.strokeBottomWeight = 0;

      // Thumbnail cell
      const thumbCell = figma.createFrame();
      thumbCell.name = "Thumbnail";
      thumbCell.layoutMode = "HORIZONTAL";
      thumbCell.counterAxisSizingMode = "FIXED";
      thumbCell.primaryAxisSizingMode = "FIXED";
      thumbCell.resize(thumbCol, 48);
      thumbCell.fills = [];
      thumbCell.paddingLeft = 8;
      thumbCell.paddingRight = 8;
      thumbCell.paddingTop = 8;
      thumbCell.paddingBottom = 8;
      thumbCell.primaryAxisAlignItems = "CENTER";
      thumbCell.counterAxisAlignItems = "CENTER";

      // Add stroke on right
      thumbCell.strokes = [{ type: 'SOLID', color: { r: 0.878, g: 0.878, b: 0.878 } }];
      thumbCell.strokeWeight = 1;
      thumbCell.strokeAlign = "INSIDE";
      thumbCell.strokeRightWeight = 1;
      thumbCell.strokeLeftWeight = 0;
      thumbCell.strokeTopWeight = 0;
      thumbCell.strokeBottomWeight = 0;

      // Create instance and scale to 24px
      const instance = component.type === 'COMPONENT'
        ? component.createInstance()
        : (component as InstanceNode).clone();

      const originalWidth = instance.width;
      const originalHeight = instance.height;
      const scale = 24 / Math.max(originalWidth, originalHeight);
      instance.resize(originalWidth * scale, originalHeight * scale);

      thumbCell.appendChild(instance);
      dataRow.appendChild(thumbCell);

      // Name cell
      const nameCell = figma.createFrame();
      nameCell.name = "Name";
      nameCell.layoutMode = "HORIZONTAL";
      nameCell.counterAxisSizingMode = "FIXED";
      nameCell.primaryAxisSizingMode = "FIXED";
      nameCell.resize(nameCol, 48);
      nameCell.fills = [];
      nameCell.paddingLeft = 8;
      nameCell.paddingRight = 8;
      nameCell.paddingTop = 8;
      nameCell.paddingBottom = 8;
      nameCell.primaryAxisAlignItems = "MIN";
      nameCell.counterAxisAlignItems = "CENTER";

      nameCell.strokes = [{ type: 'SOLID', color: { r: 0.878, g: 0.878, b: 0.878 } }];
      nameCell.strokeWeight = 1;
      nameCell.strokeAlign = "INSIDE";
      nameCell.strokeRightWeight = 1;
      nameCell.strokeLeftWeight = 0;
      nameCell.strokeTopWeight = 0;
      nameCell.strokeBottomWeight = 0;

      const nameText = figma.createText();
      nameText.characters = component.name.split('/').pop() || component.name;
      nameText.fontSize = 12;
      nameText.fontName = { family: "Inter", style: "Regular" };
      nameText.fills = [{ type: 'SOLID', color: { r: 0.118, g: 0.118, b: 0.118 } }];
      nameText.textAutoResize = "WIDTH_AND_HEIGHT";

      // Add link if enabled
      if (config.enableLabelLinks) {
        nameText.hyperlink = {
          type: 'NODE',
          value: component.id
        };
        nameText.fills = [{ type: 'SOLID', color: { r: 0.051, g: 0.6, b: 1 } }]; // Blue for links
      }

      nameCell.appendChild(nameText);
      dataRow.appendChild(nameCell);

      // Path cell
      const pathCell = figma.createFrame();
      pathCell.name = "Path";
      pathCell.layoutMode = "HORIZONTAL";
      pathCell.counterAxisSizingMode = "FIXED";
      pathCell.primaryAxisSizingMode = "FIXED";
      pathCell.resize(pathCol, 48);
      pathCell.fills = [];
      pathCell.paddingLeft = 8;
      pathCell.paddingRight = 8;
      pathCell.paddingTop = 8;
      pathCell.paddingBottom = 8;
      pathCell.primaryAxisAlignItems = "MIN";
      pathCell.counterAxisAlignItems = "CENTER";

      pathCell.strokes = [{ type: 'SOLID', color: { r: 0.878, g: 0.878, b: 0.878 } }];
      pathCell.strokeWeight = 1;
      pathCell.strokeAlign = "INSIDE";
      pathCell.strokeRightWeight = 1;
      pathCell.strokeLeftWeight = 0;
      pathCell.strokeTopWeight = 0;
      pathCell.strokeBottomWeight = 0;

      const pathText = figma.createText();
      pathText.characters = component.name;
      pathText.fontSize = 11;
      pathText.fontName = { family: "Inter", style: "Regular" };
      pathText.fills = [{ type: 'SOLID', color: { r: 0.4, g: 0.4, b: 0.4 } }];
      pathText.textAutoResize = "WIDTH_AND_HEIGHT";

      pathCell.appendChild(pathText);
      dataRow.appendChild(pathCell);

      // Size cell
      const sizeCell = figma.createFrame();
      sizeCell.name = "Size";
      sizeCell.layoutMode = "HORIZONTAL";
      sizeCell.counterAxisSizingMode = "FIXED";
      sizeCell.primaryAxisSizingMode = "FIXED";
      sizeCell.resize(sizeCol, 48);
      sizeCell.fills = [];
      sizeCell.paddingLeft = 8;
      sizeCell.paddingRight = 8;
      sizeCell.paddingTop = 8;
      sizeCell.paddingBottom = 8;
      sizeCell.primaryAxisAlignItems = "MIN";
      sizeCell.counterAxisAlignItems = "CENTER";

      const sizeText = figma.createText();
      sizeText.characters = `${Math.round(component.width)}x${Math.round(component.height)}`;
      sizeText.fontSize = 11;
      sizeText.fontName = { family: "Inter", style: "Regular" };
      sizeText.fills = [{ type: 'SOLID', color: { r: 0.4, g: 0.4, b: 0.4 } }];
      sizeText.textAutoResize = "WIDTH_AND_HEIGHT";

      sizeCell.appendChild(sizeText);
      dataRow.appendChild(sizeCell);

      mainFrame.appendChild(dataRow);
    }

    // Position frame BELOW the original icons selection
    const selectionBounds = await calculateSelectionBounds(iconIds);
    if (selectionBounds) {
      mainFrame.x = selectionBounds.minX;
      mainFrame.y = selectionBounds.maxY + 100;
    } else {
      // Fallback: use current selection position
      const selection = figma.currentPage.selection;
      if (selection.length > 0) {
        mainFrame.x = selection[0].x + selection[0].width + 100;
        mainFrame.y = selection[0].y;
      }
    }

    // Select the frame and zoom to it
    figma.currentPage.selection = [mainFrame];
    figma.viewport.scrollAndZoomIntoView([mainFrame]);

    // Send success message
    figma.ui.postMessage({
      type: 'grid-created',
      message: `Table "${config.frameName}" created successfully!`
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error creating table:', error);
    figma.ui.postMessage({
      type: 'error',
      message: `Error creating table: ${errorMessage}`
    });
  } finally {
    isCreatingGrid = false;
  }
}

// Function to recursively find all components in a node (ONLY components, not instances)
function findAllComponents(node: BaseNode, components: ComponentNode[] = []): ComponentNode[] {
  if (node.type === 'COMPONENT') {
    components.push(node as ComponentNode);
  }

  // Recursively search children
  if ('children' in node) {
    for (const child of node.children) {
      findAllComponents(child, components);
    }
  }

  return components;
}

// Function to select all components in the current page (ONLY components, not instances)
function selectAllComponentsInPage() {
  try {
    const allComponents: ComponentNode[] = [];

    // Search through all top-level nodes in the current page
    for (const node of figma.currentPage.children) {
      findAllComponents(node, allComponents);
    }

    if (allComponents.length > 0) {
      figma.currentPage.selection = allComponents;
      figma.viewport.scrollAndZoomIntoView(allComponents);
      figma.ui.postMessage({
        type: 'success',
        message: `Selected ${allComponents.length} component${allComponents.length !== 1 ? 's' : ''}`
      });
    } else {
      figma.ui.postMessage({
        type: 'error',
        message: 'No components found on this page'
      });
    }
  } catch (error) {
    console.error('Error selecting all components:', error);
    figma.ui.postMessage({
      type: 'error',
      message: 'Error selecting components'
    });
  }
}

// Handle messages from UI
figma.ui.onmessage = async (msg) => {
  switch (msg.type) {
    case 'get-icons':
      try {
        const components = getSelectedComponents();

        if (components.length === 0) {
          figma.ui.postMessage({ type: 'no-selection' });
          return;
        }

        // Generate thumbnails for all components
        const iconsData: IconData[] = [];
        for (const component of components) {
          try {
            const iconData = await getIconData(component);
            iconsData.push(iconData);
          } catch (error) {
            console.error('Skipping component due to error:', component.name);
          }
        }

        // Build tree structure from components
        const tree = buildTreeFromComponents(components);

        // Attach thumbnails to tree (async)
        await attachThumbnailsToTree(tree);

        // Send icons data and tree to UI
        figma.ui.postMessage({
          type: 'icons-loaded',
          icons: iconsData,
          tree: tree
        });

      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error loading icons: ${errorMessage}`
        });
      }
      break;

    case 'create-grid':
      await createGridOnCanvas(msg.config, msg.iconIds);
      // Save user preferences after successful grid creation
      await saveGridConfigAsPreferences(msg.config);
      break;

    case 'create-table':
      await createTableOnCanvas(msg.config, msg.iconIds);
      // Save user preferences after successful table creation
      await saveGridConfigAsPreferences(msg.config);
      break;

    case 'select-all-components':
      selectAllComponentsInPage();
      break;

    case 'view-icon':
      try {
        const nodeToView = await figma.getNodeByIdAsync(msg.iconId) as SceneNode;
        if (nodeToView) {
          // Select the node
          figma.currentPage.selection = [nodeToView];
          // Zoom to the node
          figma.viewport.scrollAndZoomIntoView([nodeToView]);
          // Send success feedback
          figma.ui.postMessage({
            type: 'view-icon-success',
            iconName: nodeToView.name
          });
        } else {
          figma.ui.postMessage({
            type: 'error',
            message: `Icon not found with ID: ${msg.iconId}`
          });
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error viewing icon: ${errorMessage}`
        });
      }
      break;

    case 'export-svgr':
      await batchExportSVGR(msg.iconIds, msg.config);
      break;

    case 'rename-icon':
      try {
        const node = await figma.getNodeByIdAsync(msg.iconId) as ComponentNode | InstanceNode;
        if (node && (node.type === 'COMPONENT' || node.type === 'INSTANCE')) {
          node.name = msg.newName;

          // Refresh icons to show updated name
          const components = getSelectedComponents();
          const iconsData: IconData[] = [];
          for (const component of components) {
            try {
              const iconData = await getIconData(component);
              iconsData.push(iconData);
            } catch (error) {
              console.error('Skipping component due to error:', component.name);
            }
          }

          const tree = buildTreeFromComponents(components);
          await attachThumbnailsToTree(tree);

          figma.ui.postMessage({
            type: 'icons-loaded',
            icons: iconsData,
            tree: tree
          });

          figma.ui.postMessage({
            type: 'success',
            message: `Renamed to "${msg.newName}"`
          });
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error renaming icon: ${errorMessage}`
        });
      }
      break;

    case 'bulk-rename':
      try {
        let successCount = 0;
        for (const rename of msg.renames) {
          try {
            const node = await figma.getNodeByIdAsync(rename.iconId) as ComponentNode | InstanceNode;
            if (node && (node.type === 'COMPONENT' || node.type === 'INSTANCE')) {
              node.name = rename.newName;
              successCount++;
            }
          } catch (error) {
            console.error('Error renaming icon:', rename.iconId, error);
          }
        }

        // Refresh icons to show updated names
        const components = getSelectedComponents();
        const iconsData: IconData[] = [];
        for (const component of components) {
          try {
            const iconData = await getIconData(component);
            iconsData.push(iconData);
          } catch (error) {
            console.error('Skipping component due to error:', component.name);
          }
        }

        const tree = buildTreeFromComponents(components);
        await attachThumbnailsToTree(tree);

        figma.ui.postMessage({
          type: 'icons-loaded',
          icons: iconsData,
          tree: tree
        });

        figma.ui.postMessage({
          type: 'success',
          message: `Renamed ${successCount} icon${successCount !== 1 ? 's' : ''}`
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error bulk renaming: ${errorMessage}`
        });
      }
      break;

    case 'set-badge':
      try {
        const node = await figma.getNodeByIdAsync(msg.iconId);
        if (node && (node.type === 'COMPONENT' || node.type === 'INSTANCE')) {
          const badge: BadgeData = {
            type: msg.badgeType,
            timestamp: Date.now(),
            color: msg.color
          };
          setBadge(node, badge);

          figma.ui.postMessage({
            type: 'success',
            message: `Badge "${msg.badgeType}" added to ${node.name}`
          });

          // Refresh icons to show badge
          const components = getSelectedComponents();
          const iconsData: IconData[] = [];
          for (const component of components) {
            try {
              const iconData = await getIconData(component);
              iconsData.push(iconData);
            } catch (error) {
              console.error('Skipping component due to error:', component.name);
            }
          }

          const tree = buildTreeFromComponents(components);
          await attachThumbnailsToTree(tree);

          figma.ui.postMessage({
            type: 'icons-loaded',
            icons: iconsData,
            tree: tree
          });
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error setting badge: ${errorMessage}`
        });
      }
      break;

    case 'remove-badge':
      try {
        const node = await figma.getNodeByIdAsync(msg.iconId);
        if (node && (node.type === 'COMPONENT' || node.type === 'INSTANCE')) {
          removeBadge(node);

          figma.ui.postMessage({
            type: 'success',
            message: 'Badge removed'
          });

          // Refresh icons
          const components = getSelectedComponents();
          const iconsData: IconData[] = [];
          for (const component of components) {
            try {
              const iconData = await getIconData(component);
              iconsData.push(iconData);
            } catch (error) {
              console.error('Skipping component due to error:', component.name);
            }
          }

          const tree = buildTreeFromComponents(components);
          await attachThumbnailsToTree(tree);

          figma.ui.postMessage({
            type: 'icons-loaded',
            icons: iconsData,
            tree: tree
          });
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error removing badge: ${errorMessage}`
        });
      }
      break;

    case 'bulk-set-badge':
      try {
        let successCount = 0;
        for (const iconId of msg.iconIds) {
          try {
            const node = await figma.getNodeByIdAsync(iconId);
            if (node && (node.type === 'COMPONENT' || node.type === 'INSTANCE')) {
              const badge: BadgeData = {
                type: msg.badgeType,
                timestamp: Date.now(),
                color: msg.color
              };
              setBadge(node, badge);
              successCount++;
            }
          } catch (error) {
            console.error('Error setting badge for icon:', iconId, error);
          }
        }

        // Refresh icons
        const components = getSelectedComponents();
        const iconsData: IconData[] = [];
        for (const component of components) {
          try {
            const iconData = await getIconData(component);
            iconsData.push(iconData);
          } catch (error) {
            console.error('Skipping component due to error:', component.name);
          }
        }

        const tree = buildTreeFromComponents(components);
        await attachThumbnailsToTree(tree);

        figma.ui.postMessage({
          type: 'icons-loaded',
          icons: iconsData,
          tree: tree
        });

        figma.ui.postMessage({
          type: 'success',
          message: `Badge applied to ${successCount} icon${successCount !== 1 ? 's' : ''}`
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        figma.ui.postMessage({
          type: 'error',
          message: `Error bulk setting badges: ${errorMessage}`
        });
      }
      break;

    case 'cancel':
      figma.closePlugin();
      break;

    default:
      console.log('Unknown message type:', msg.type);
  }
};

// Initialize: Request icons on startup
figma.ui.postMessage({ type: 'init' });

// Listen for selection changes and auto-reload icons
figma.on('selectionchange', () => {
  // Skip if currently creating grid to avoid interference
  if (isCreatingGrid) {
    return;
  }

  const components = getSelectedComponents();

  if (components.length === 0) {
    figma.ui.postMessage({ type: 'no-selection' });
    return;
  }

  // Auto-reload icons when selection changes
  (async () => {
    try {
      const iconsData: IconData[] = [];
      for (const component of components) {
        try {
          const iconData = await getIconData(component);
          iconsData.push(iconData);
        } catch (error) {
          console.error('Skipping component due to error:', component.name);
        }
      }

      // Build tree structure
      const tree = buildTreeFromComponents(components);
      await attachThumbnailsToTree(tree);

      figma.ui.postMessage({
        type: 'icons-loaded',
        icons: iconsData,
        tree: tree
      });
    } catch (error) {
      console.error('Error in selectionchange handler:', error);
    }
  })();
});
